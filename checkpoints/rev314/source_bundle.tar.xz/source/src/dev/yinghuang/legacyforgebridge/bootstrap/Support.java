package dev.yinghuang.legacyforgebridge.bootstrap;
import java.io.*;import java.nio.channels.*;import java.nio.file.*;import java.security.*;import java.util.*;
/** Shared disk protocol for bootstrap and the game. All paths are scoped to one instance. */
public final class Support {
 public static final String BUILD="rev314-uv-layout.1", PREFS="config/legacyforgebridge-modules.properties";
 public static final String TICKET="lfb/launch-ticket.properties", STATE="lfb/bootstrap-state.properties", JOURNAL="lfb/transaction.properties";
 public static Properties load(Path p)throws IOException{Properties v=new Properties();if(Files.isRegularFile(p))try(InputStream s=Files.newInputStream(p)){v.load(s);}return v;}
 public static void save(Path p,Properties v)throws IOException{ByteArrayOutputStream s=new ByteArrayOutputStream();v.store(s,"LFB "+BUILD);write(p,s.toByteArray());}
 public static void write(Path p,byte[] bytes)throws IOException{
  Files.createDirectories(p.getParent());Path t=Files.createTempFile(p.getParent(),".lfb-write-",".tmp");
  try{try(FileChannel c=FileChannel.open(t,StandardOpenOption.WRITE)){java.nio.ByteBuffer b=java.nio.ByteBuffer.wrap(bytes);while(b.hasRemaining())c.write(b);c.force(true);}move(t,p);}finally{Files.deleteIfExists(t);}
 }
 public static void move(Path src,Path dst)throws IOException{try{Files.move(src,dst,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(src,dst,StandardCopyOption.REPLACE_EXISTING);}}
 public static String sha(Path p)throws IOException{try{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=Files.newInputStream(p)){byte[] b=new byte[65536];for(int n;(n=in.read(b))!=-1;)d.update(b,0,n);}return HexFormat.of().formatHex(d.digest());}catch(NoSuchAlgorithmException e){throw new AssertionError(e);}}
 public static String textSha(String s){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8)));}catch(Exception e){throw new AssertionError(e);}}
 public static List<Path> sources(Path g)throws IOException{Path d=g.resolve("old-mods");if(!Files.isDirectory(d))return List.of();try(var s=Files.list(d)){return s.filter(p->Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS)&&p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".jar")).sorted(Comparator.comparing(p->p.getFileName().toString())).toList();}}
 public static boolean enabled(Properties p,String name)throws IOException{String v=p.getProperty("enabled."+name,"true");if(!v.equalsIgnoreCase("true")&&!v.equalsIgnoreCase("false"))throw new IOException("Invalid enable flag for "+name);return Boolean.parseBoolean(v);}
 public static String inventory(Path g)throws IOException{Properties p=load(g.resolve(PREFS));StringBuilder b=new StringBuilder();for(Path f:sources(g)){String n=f.getFileName().toString();b.append(n.length()).append(':').append(n).append(':').append(enabled(p,n)).append(':').append(sha(f)).append('\n');}return textSha(b.toString());}
 public static Path scoped(Path g,String rel)throws IOException{if(rel==null||rel.isBlank())throw new IOException("Empty managed path");Path x=g.resolve(rel).normalize();if(!x.startsWith(g)||Path.of(rel).isAbsolute())throw new IOException("Path escapes instance: "+rel);for(Path p=x;p!=null&&!p.equals(g);p=p.getParent())if(Files.isSymbolicLink(p))throw new IOException("Symlink is not allowed for managed paths: "+p);return x;}
 public static String relative(Path g,Path p)throws IOException{Path x=p.toAbsolutePath().normalize();if(!x.startsWith(g))throw new IOException("Path outside instance: "+x);return g.relativize(x).toString().replace('\\','/');}
 public static Path ownJar(Class<?> c)throws Exception{return Path.of(c.getProtectionDomain().getCodeSource().getLocation().toURI()).toAbsolutePath().normalize();}
 public static int count(Properties p,String key)throws IOException{try{int n=Integer.parseInt(p.getProperty(key,"0"));if(n<0||n>10000)throw new NumberFormatException();return n;}catch(Exception e){throw new IOException("Invalid state count: "+key,e);}}
 public static SessionLock lock(Path game)throws IOException{return new SessionLock(game);}
 public static final class SessionLock implements AutoCloseable{
  final FileChannel channel;final FileLock lock;
  SessionLock(Path g)throws IOException{Files.createDirectories(g.resolve("lfb"));channel=FileChannel.open(g.resolve("lfb/session.lock"),StandardOpenOption.CREATE,StandardOpenOption.WRITE);FileLock acquired;
   try{acquired=channel.tryLock();}catch(OverlappingFileLockException e){channel.close();throw new IOException("LFB: this instance is already running or converting",e);}if(acquired==null){channel.close();throw new IOException("LFB: close this instance before another conversion/start");}lock=acquired;
  }
  public void close()throws IOException{try{lock.release();}finally{channel.close();}}
 }
 private Support(){}
}
