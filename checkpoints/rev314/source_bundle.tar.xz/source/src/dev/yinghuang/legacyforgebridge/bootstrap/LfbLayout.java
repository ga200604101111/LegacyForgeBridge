package dev.yinghuang.legacyforgebridge.bootstrap;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;

/**
 * LFB-owned directory migration. Caller must already hold Support.sessionLock.
 * Original mods, ordinary Minecraft logs, .fabric and launcher libraries are never moved.
 * Conflicts are retained in a timestamped backup, not silently overwritten.
 */
public final class LfbLayout {
    private LfbLayout() {}
    public static void prepare(Path game) throws IOException {
        Path old=game.resolve("legacy-cache"), cache=game.resolve("lfb/cache"), logs=game.resolve("lfb/logs");
        checkTree(game,game.resolve("lfb"));
        if(Files.exists(old,LinkOption.NOFOLLOW_LINKS)) checkTree(game,old);
        Files.createDirectories(logs);
        Path backup=game.resolve("lfb/backups/layout-"+System.currentTimeMillis()+"-"+UUID.randomUUID().toString().substring(0,8));
        List<String> events=new ArrayList<>();
        boolean rewriteNeeded=Files.exists(old)||!"2".equals(Support.load(game.resolve("lfb/layout.properties")).getProperty("schema"));
        if(Files.isDirectory(old)) {
            if(!Files.exists(cache)) {Files.move(old,cache);events.add("Moved legacy-cache -> lfb/cache");}
            else {
                if(!Files.isDirectory(cache)) throw new IOException("lfb/cache is occupied by a file");
                merge(game,old,cache,backup.resolve("legacy-cache-conflicts"),events);
            }
        }
        Files.createDirectories(cache);
        // Rewrite only live cache indexes. Historical manifests/diagnostics remain evidence,
        // and their original path text must not be silently rewritten.
        if(rewriteNeeded) for(String name:List.of("conversion-state.json","index.properties")) {
            Path p=cache.resolve(name);
            if(Files.isRegularFile(p)) {
                if(Files.size(p)>32L*1024*1024)throw new IOException("Cache state exceeds migration size limit: "+p);
                rewrite(game,p,backup,events);
            }
        }
        if(rewriteNeeded) for(String name:List.of("bootstrap-state.properties","launch-ticket.properties","transaction.properties")) {
            Path p=game.resolve("lfb").resolve(name);if(Files.isRegularFile(p))rewrite(game,p,backup,events);
        }
        // Old log locations are imported as history, never merged into another live writer.
        for(String name:List.of("bootstrap.log","bootstrap.previous.log","preflight.log"))
            archive(game,game.resolve("lfb").resolve(name),logs.resolve("archive"),events);
        archive(game,game.resolve("logs/legacyforgebridge.log"),logs.resolve("archive"),events);
        for(String name:List.of("lfb-motion","lfb-s12")) {
            Path from=game.resolve("logs").resolve(name), to=logs.resolve(name);
            if(Files.exists(from,LinkOption.NOFOLLOW_LINKS)){
                checkTree(game,from);
                if(!Files.exists(to)){Files.move(from,to);events.add("Moved logs/"+name+" -> lfb/logs/"+name);}
                else merge(game,from,to,backup.resolve("log-conflicts/"+name),events);
            }
        }
        // Keep two known live-log generations, as the bootstrap did before this migration.
        Path runtime=logs.resolve("runtime.log");
        if(Files.isRegularFile(runtime))Files.move(runtime,logs.resolve("runtime.previous.log"),StandardCopyOption.REPLACE_EXISTING);
        if(!events.isEmpty()) {
            String report=Instant.now()+"\n"+String.join("\n",events)+"\n";
            Files.writeString(logs.resolve("layout-migration.log"),report,StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);
            System.out.println("[LFB] LAYOUT_READY: cache=lfb/cache logs=lfb/logs; migrated records="+events.size());
        }
        Properties mark=new Properties();mark.setProperty("schema","2");mark.setProperty("cache","lfb/cache");mark.setProperty("logs","lfb/logs");
        Support.save(game.resolve("lfb/layout.properties"),mark);
    }
    private static void checkTree(Path game,Path root)throws IOException {
        if(!Files.exists(root,LinkOption.NOFOLLOW_LINKS))return;
        try(var stream=Files.walk(root)) {for(Path p:stream.toList()){
            if(Files.isSymbolicLink(p)||!p.toRealPath().startsWith(game.toRealPath()))throw new IOException("Refusing linked/outside managed path: "+p);
        }}
    }
    private static void merge(Path game,Path from,Path to,Path backup,List<String> events)throws IOException {
        if(!Files.isDirectory(from)||!Files.isDirectory(to))throw new IOException("Migration directory/file conflict: "+from+" / "+to);
        checkTree(game,to);
        try(var stream=Files.walk(from)) {
            for(Path p:stream.sorted().toList()) {
                Path rel=from.relativize(p), dst=to.resolve(rel);
                if(Files.isDirectory(p)) {
                    if(Files.exists(dst)&&!Files.isDirectory(dst))throw new IOException("Migration path occupied: "+dst);
                    Files.createDirectories(dst);
                } else if(Files.isRegularFile(p,LinkOption.NOFOLLOW_LINKS)) {
                    if(Files.exists(dst)) {
                        Path saved=backup.resolve(rel);Files.createDirectories(saved.getParent());Files.move(p,saved);
                        events.add("Preserved old duplicate/conflict: "+game.relativize(saved));
                    } else {Files.createDirectories(dst.getParent());Files.move(p,dst);}
                } else throw new IOException("Unsupported cache entry: "+p);
            }
        }
        try(var stream=Files.walk(from)){for(Path p:stream.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}
        events.add("Merged "+game.relativize(from)+" -> "+game.relativize(to)+"; conflicting old files kept");
    }
    private static void archive(Path game,Path from,Path archive,List<String> events)throws IOException {
        if(!Files.exists(from,LinkOption.NOFOLLOW_LINKS))return;
        if(!Files.isRegularFile(from,LinkOption.NOFOLLOW_LINKS))throw new IOException("Log path is not an ordinary file: "+from);
        Files.createDirectories(archive);Path dst=archive.resolve(System.currentTimeMillis()+"-"+UUID.randomUUID().toString().substring(0,8)+"-"+from.getFileName());
        Files.move(from,dst);events.add("Archived "+game.relativize(from)+" -> "+game.relativize(dst));
    }
    private static String convertPath(String s) {
        if(s.equals("legacy-cache"))return "lfb/cache";
        if(s.startsWith("legacy-cache/"))return "lfb/cache/"+s.substring(13);
        if(s.startsWith("legacy-cache\\"))return "lfb/cache/"+s.substring(13).replace('\\','/');
        return s;
    }
    private static void rewrite(Path game,Path path,Path backup,List<String> events)throws IOException {
        byte[] before=Files.readAllBytes(path),after=before;
        if(path.getFileName().toString().endsWith(".properties")) {
            Properties p=Support.load(path);boolean changed=false;
            for(String k:p.stringPropertyNames()){String v=p.getProperty(k),n=convertPath(v);if(!n.equals(v)){p.setProperty(k,n);changed=true;}}
            if(changed){ByteArrayOutputStream out=new ByteArrayOutputStream();p.store(out,"LFB layout migration; source/candidate hashes unchanged");after=out.toByteArray();}
        } else {
            String s=new String(before,StandardCharsets.UTF_8);
            // Restrict to complete JSON string prefixes; never replace strings inside class/JAR bytes.
            String n=s.replace("\"legacy-cache/","\"lfb/cache/");
            if(!n.equals(s)){
                try{JsonLite.parse(s);JsonLite.parse(n);}catch(RuntimeException e){throw new IOException("Cannot migrate malformed cache JSON: "+path,e);}
                after=n.getBytes(StandardCharsets.UTF_8);
            }
        }
        if(!Arrays.equals(before,after)) {
            Path saved=backup.resolve("state-before-rewrite").resolve(game.relativize(path));Files.createDirectories(saved.getParent());Files.write(saved,before,StandardOpenOption.CREATE_NEW);
            Support.write(path,after);events.add("Updated cached path fields: "+game.relativize(path));
        }
    }
}
