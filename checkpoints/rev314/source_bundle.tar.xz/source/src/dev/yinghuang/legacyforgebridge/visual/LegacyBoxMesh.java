package dev.yinghuang.legacyforgebridge.visual;

import java.util.List;

/**
 * CPU-only legacy ModelBox topology and UVs. Coordinates are model pixels; UVs
 * are normalized. Top/bottom refer to legacy model Y, not world attachment Y.
 * No source classes or game renderer are loaded here.
 */
public final class LegacyBoxMesh {
    public record Vertex(float x, float y, float z, float u, float v) {}
    public record Face(String name, float nx, float ny, float nz, List<Vertex> vertices) {}
    private LegacyBoxMesh() {}

    public static List<Face> create(int u, int v, float x, float y, float z,
            float width, float uvHeight, float depth, float geometryHeight,
            float textureWidth, float textureHeight) {
        if (!(textureWidth > 0 && textureHeight > 0 && width > 0 && depth > 0
                && uvHeight >= 0 && geometryHeight >= 0)) {
            throw new IllegalArgumentException("Invalid legacy box dimensions");
        }
        float[][] p = {
            {x,y,z}, {x+width,y,z}, {x+width,y+geometryHeight,z}, {x,y+geometryHeight,z},
            {x,y,z+depth}, {x+width,y,z+depth}, {x+width,y+geometryHeight,z+depth}, {x,y+geometryHeight,z+depth}
        };
        return List.of(
            face("east", 1,0,0, p, new int[]{5,1,2,6}, u+depth+width,v+depth,u+depth+width+depth,v+depth+uvHeight,textureWidth,textureHeight),
            face("west",-1,0,0, p, new int[]{0,4,7,3}, u,v+depth,u+depth,v+depth+uvHeight,textureWidth,textureHeight),
            face("down",0,-1,0,p,new int[]{5,4,0,1},u+depth,v,u+depth+width,v+depth,textureWidth,textureHeight),
            face("up",0,1,0,p,new int[]{2,3,7,6},u+depth+width,v+depth,u+depth+width+width,v,textureWidth,textureHeight),
            face("north",0,0,-1,p,new int[]{1,0,3,2},u+depth,v+depth,u+depth+width,v+depth+uvHeight,textureWidth,textureHeight),
            face("south",0,0,1,p,new int[]{4,5,6,7},u+depth+width+depth,v+depth,u+depth+width+depth+width,v+depth+uvHeight,textureWidth,textureHeight)
        );
    }
    private static Face face(String name,float nx,float ny,float nz,float[][] p,int[] ix,
            float u1,float v1,float u2,float v2,float tw,float th) {
        float[][] uv={{u2/tw,v1/th},{u1/tw,v1/th},{u1/tw,v2/th},{u2/tw,v2/th}};
        Vertex[] a=new Vertex[4];
        for(int i=0;i<4;i++) {float[] q=p[ix[i]]; a[i]=new Vertex(q[0],q[1],q[2],uv[i][0],uv[i][1]);}
        return new Face(name,nx,ny,nz,List.of(a));
    }
}
