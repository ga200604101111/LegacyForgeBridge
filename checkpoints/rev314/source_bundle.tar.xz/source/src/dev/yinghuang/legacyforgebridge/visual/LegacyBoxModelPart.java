package dev.yinghuang.legacyforgebridge.visual;

import net.minecraft.class_630;
import net.minecraft.class_2350;
import org.joml.Vector3f;
import java.util.*;

/** Exact source-style per-face UVs, independent of modern cuboid UV generation. */
public final class LegacyBoxModelPart {
    private LegacyBoxModelPart() {}
    public static class_630 create(int u,int v,float x,float y,float z,int w,int h,int d,boolean glow) {
        float height=glow&&h==0 ? 1f/256f : h;
        var cube=new class_630.class_628(u,v,x,y,z,w,height,d,0,0,0,false,64,32,EnumSet.allOf(class_2350.class));
        var faces=LegacyBoxMesh.create(u,v,x,y,z,w,h,d,height,64,32);
        if(cube.field_3649.length!=faces.size()) throw new IllegalStateException("Unexpected Minecraft cuboid face count");
        for(int i=0;i<faces.size();i++) {
            var face=faces.get(i); var vertices=new class_630.class_618[4];
            for(int j=0;j<4;j++){var p=face.vertices().get(j);vertices[j]=new class_630.class_618(p.x(),p.y(),p.z(),p.u(),p.v());}
            cube.field_3649[i]=new class_630.class_593(vertices,new Vector3f(face.nx(),face.ny(),face.nz()));
        }
        return new class_630(List.of(cube),Map.of());
    }
}
