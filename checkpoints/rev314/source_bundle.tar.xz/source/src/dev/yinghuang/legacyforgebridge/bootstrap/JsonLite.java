package dev.yinghuang.legacyforgebridge.bootstrap;
import java.util.*;
/** Small strict JSON reader used only to locate existing launcher libraries, before Gson is loaded. */
public final class JsonLite {
 private final String s;private int i;
 private JsonLite(String s){this.s=s;}
 public static Object parse(String s){JsonLite p=new JsonLite(s);Object o=p.value(0);p.ws();if(p.i!=s.length())throw p.error();return o;}
 private RuntimeException error(){return new IllegalArgumentException("Invalid JSON at "+i);}
 private void ws(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
 private Object value(int d){if(d>64)throw error();ws();if(i>=s.length())throw error();char c=s.charAt(i++);
  if(c=='"')return str();if(c=='{'){Map<String,Object> m=new LinkedHashMap<>();ws();if(eat('}'))return m;do{ws();if(!eat('"'))throw error();String k=str();ws();if(!eat(':'))throw error();if(m.containsKey(k))throw error();m.put(k,value(d+1));ws();if(eat('}'))return m;}while(eat(','));throw error();}
  if(c=='['){List<Object> l=new ArrayList<>();ws();if(eat(']'))return l;do{l.add(value(d+1));ws();if(eat(']'))return l;}while(eat(','));throw error();}
  i--;for(String t:List.of("true","false","null"))if(s.startsWith(t,i)){i+=t.length();return t.equals("null")?null:t.equals("true");}
  int p=i;while(i<s.length()&&"-+0123456789.eE".indexOf(s.charAt(i))>=0)i++;if(p==i)throw error();return new java.math.BigDecimal(s.substring(p,i));
 }
 private boolean eat(char c){if(i<s.length()&&s.charAt(i)==c){i++;return true;}return false;}
 private String str(){StringBuilder b=new StringBuilder();while(i<s.length()){char c=s.charAt(i++);if(c=='"')return b.toString();if(c=='\\'){if(i==s.length())throw error();c=s.charAt(i++);switch(c){case '"','\\','/'->b.append(c);case 'b'->b.append('\b');case 'f'->b.append('\f');case 'n'->b.append('\n');case 'r'->b.append('\r');case 't'->b.append('\t');case 'u'->{if(i+4>s.length())throw error();b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;}default->throw error();}}else{if(c<32)throw error();b.append(c);}}throw error();}
}
