package dev.yinghuang.legacyforgebridge.bootstrap;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Prism's pre-launch entry point: the same independent worker with the original rev313 desktop UI. */
public final class BootstrapMain {
    public static void main(String[] args) {
        int code=1;Path game=null;PrintStream log=null;
        OriginalDesktopUi ui=null;ProgressModel model=null;
        try {
            if(Runtime.version().feature()<21)throw new IOException("Java 21 or later is required");
            if(args.length!=1)throw new IOException("Usage: java -Xmx2G -jar LFB-Bootstrap.jar <Minecraft folder>");
            game=Path.of(args[0]).toAbsolutePath().normalize().toRealPath();
            if(!Files.isDirectory(game.resolve("mods")))throw new IOException("Choose the Minecraft folder containing mods: "+game);
            Path lfb=game.resolve("lfb");Files.createDirectories(lfb);Path logfile=lfb.resolve("logs/bootstrap.log");
            // Preserve the lock-before-log/ticket behavior of the previous package.
            try(Support.SessionLock lock=Support.lock(game)) {
                try {
                    Files.deleteIfExists(game.resolve(Support.TICKET));
                    LfbLayout.prepare(game);
                    if(Files.isRegularFile(logfile))Files.move(logfile,lfb.resolve("logs/bootstrap.previous.log"),StandardCopyOption.REPLACE_EXISTING);
                    Tee tee=new Tee(System.out,Files.newOutputStream(logfile));
                    log=new PrintStream(tee,true,StandardCharsets.UTF_8);System.setOut(log);System.setErr(log);
                    System.out.println("[LFB] START "+Support.BUILD+" ui=original-rev313-ui.2-no-restart independentJvmPid="+ProcessHandle.current().pid()+" game="+game);
                    System.out.println("[LFB] No Minecraft client, Fabric entrypoints or original Forge classes will be launched by this process.");
                    model=new ProgressModel(game);tee.model=model;
                    try{ui=new OriginalDesktopUi(game,model);}catch(Exception e){System.err.println("[LFB] Original window could not be opened; see lfb/logs/bootstrap.log: "+e);}
                    Path home=Support.ownJar(BootstrapMain.class).getParent();Properties bundle=Support.load(home.resolve("bundle.properties"));
                    Path core=home.resolve("LFB-Converter.jar");String expected=bundle.getProperty("coreSha256");
                    if(expected==null||!Support.sha(core).equals(expected))throw new IOException("LFB-Converter.jar does not match bundle.properties; reinstall this package");
                    String runtime=bundle.getProperty("runtimeSha256");if(runtime==null)throw new IOException("Missing runtime hash in bundle.properties");
                    List<Path> dependencies=DependencyLocator.find(game);List<URL> urls=new ArrayList<>();urls.add(core.toUri().toURL());
                    for(Path p:dependencies)urls.add(p.toUri().toURL());
                    StringBuilder provenance=new StringBuilder("# Runtime dependencies selected from this instance\n");
                    for(Path p:dependencies)provenance.append(p).append('\n');
                    Support.write(lfb.resolve("logs/dependency-paths.txt"),provenance.toString().getBytes(StandardCharsets.UTF_8));
                    ClassLoader previous=Thread.currentThread().getContextClassLoader();
                    try(URLClassLoader cl=new URLClassLoader(urls.toArray(URL[]::new),ClassLoader.getPlatformClassLoader())) {
                        Thread.currentThread().setContextClassLoader(cl);
                        URL logging=cl.getResource("legacyforgebridge/bootstrap-log4j2.xml");
                        if(logging!=null){System.setProperty("log4j.configurationFile",logging.toString());System.setProperty("log4j2.configurationFile",logging.toString());}
                        code=(Integer)cl.loadClass("dev.yinghuang.legacyforgebridge.bootstrap.ConversionWorker")
                            .getMethod("run",String.class,String.class).invoke(null,game.toString(),runtime);
                    }finally{Thread.currentThread().setContextClassLoader(previous);}
                    if(code==0&&!Files.isRegularFile(game.resolve(Support.TICKET)))throw new IOException("Worker returned without a launch ticket; Minecraft remains blocked");
                    code=model.complete(code,null);
                    if(code!=0)Files.deleteIfExists(game.resolve(Support.TICKET));
                    System.out.println("[LFB] EXIT code="+code+(code==0?". Prism may now start Minecraft.":". Minecraft remains blocked."));
                    if(ui!=null)ui.finishDisplay(code);
                }catch(Throwable failure) {
                    try{Files.deleteIfExists(game.resolve(Support.TICKET));}catch(IOException cleanup){failure.addSuppressed(cleanup);}
                    throw failure;
                }
            }
        }catch(Throwable raw) {
            code=1;Throwable failure=raw;
            while(failure instanceof InvocationTargetException&&failure.getCause()!=null)failure=failure.getCause();
            System.err.println("[LFB] PREPARE_FAILED: "+failure);failure.printStackTrace(System.err);
            if(model!=null)model.complete(1,failure);
            if(ui!=null)ui.finishDisplay(1);
        }finally {
            if(ui!=null)ui.close();if(log!=null)log.flush();
        }
        // The converter process (including its UI) exits before Prism can start the game JVM.
        System.exit(code);
    }
    private static final class Tee extends OutputStream {
        private final OutputStream console,file;private final ByteArrayOutputStream line=new ByteArrayOutputStream();
        private volatile ProgressModel model;
        Tee(OutputStream console,OutputStream file){this.console=console;this.file=file;}
        public synchronized void write(int b)throws IOException{console.write(b);file.write(b);scan(b);}
        public synchronized void write(byte[] b,int off,int len)throws IOException{console.write(b,off,len);file.write(b,off,len);for(int i=off;i<off+len;i++)scan(b[i]&255);}
        private void scan(int b){
            if(b=='\n'){
                String text=line.toString(StandardCharsets.UTF_8).replace("\r","");line.reset();
                ProgressModel m=model;if(m!=null)try{m.accept(text);}catch(RuntimeException ignored){/* UI cannot corrupt conversion. */}
            }else if(line.size()<8192)line.write(b);
        }
        public synchronized void flush()throws IOException{console.flush();file.flush();}
    }
}
