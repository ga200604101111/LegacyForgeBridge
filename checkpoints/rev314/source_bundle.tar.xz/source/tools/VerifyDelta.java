import java.io.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
/** Verifies changed methods in the packaged output, without loading game/source classes. */
public final class VerifyDelta{
 static int classes,methods,nested;
 static Map<String,byte[]> entries(byte[] b)throws Exception {Map<String,byte[]> r=new TreeMap<>();try(var z=new ZipInputStream(new ByteArrayInputStream(b))){for(ZipEntry e;(e=z.getNextEntry())!=null;){if(r.put(e.getName(),z.readAllBytes())!=null)throw new IOException("duplicate "+e.getName());}}return r;}
 static void verify(byte[] a,byte[] b)throws Exception {var before=entries(a);var after=entries(b);for(var e:after.entrySet()){
  String n=e.getKey();byte[] v=e.getValue();if(Arrays.equals(v,before.get(n)))continue;
  if(n.endsWith(".class")){ClassNode c=new ClassNode();new ClassReader(v).accept(c,0);classes++;for(MethodNode m:c.methods)if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0){new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);methods++;}}
  if(n.endsWith(".jar")&&before.containsKey(n)){nested++;verify(before.get(n),v);}
 }}
 public static void main(String[] a)throws Exception {if(a.length%2!=0)throw new IllegalArgumentException("before after pairs");for(int i=0;i<a.length;i+=2)verify(Files.readAllBytes(Path.of(a[i])),Files.readAllBytes(Path.of(a[i+1])));System.out.println("PASS ASM BasicVerifier: changed/new classes="+classes+", methods="+methods+", nested jars="+nested+"; no Minecraft API linkage or runtime rendering claim");}
}
