"""Build legacy ModelBox fallback templates from original client model constants.
All constants checked against the supplied SHA-pinned original model constructors.
No texture painting or geometry enlargement. H=0 glow uses finite geometry only.
"""
from pathlib import Path
from zipfile import ZipFile
import json, math, hashlib, itertools, os
from PIL import Image
from io import BytesIO
W=Path(__file__).resolve().parents[1]
SRC=Path(os.environ.get('LFB_TF_SOURCE', '/mnt/data/twilightforest-1.7.10-2.3.8-tw.jar'))
PIN='1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589'
BOXES={
 'cicada':[(0,21,-4,7.9,-5,8,1,9),(0,11,-2,6,-4,4,2,6),(0,0,-1,7,-5,2,1,8),(20,15,1,5,2,2,2,2),(20,15,-3,5,2,2,2,2),(20,0,-4,5,-7,8,1,8)],
 'firefly':[(0,21,-4,7.9,-5,8,1,10),(0,11,-2,6,-4,4,2,6),(0,0,-1,7,-5,2,1,8),(20,0,-5,5.9,-9,10,0,10)]}
DIRECTIONS={'east':(1,0,0),'west':(-1,0,0),'down':(0,-1,0),'up':(0,1,0),'north':(0,0,-1),'south':(0,0,1)}
# FaceInfo winding used by Minecraft's JSON block face bakery.
ORDER={'down':[(0,0,1),(0,0,0),(1,0,0),(1,0,1)],'up':[(0,1,0),(0,1,1),(1,1,1),(1,1,0)],
 'north':[(1,1,0),(1,0,0),(0,0,0),(0,1,0)],'south':[(0,1,1),(0,0,1),(1,0,1),(1,1,1)],
 'west':[(0,1,0),(0,0,0),(0,0,1),(0,1,1)],'east':[(1,1,1),(1,0,1),(1,0,0),(1,1,0)]}
def faces(b):
 u,v,x,y,z,w,h,d=b; gh=1/256 if h==0 else h
 p=[(x,y,z),(x+w,y,z),(x+w,y+gh,z),(x,y+gh,z),(x,y,z+d),(x+w,y,z+d),(x+w,y+gh,z+d),(x,y+gh,z+d)]
 specs=[('east',[5,1,2,6],(u+d+w,v+d,u+d+w+d,v+d+h)),('west',[0,4,7,3],(u,v+d,u+d,v+d+h)),
 ('down',[5,4,0,1],(u+d,v,u+d+w,v+d)),('up',[2,3,7,6],(u+d+w,v+d,u+d+w+w,v)),
 ('north',[1,0,3,2],(u+d,v+d,u+d+w,v+d+h)),('south',[4,5,6,7],(u+d+w+d,v+d,u+d+w+d+w,v+d+h))]
 out=[]
 for name,ix,rect in specs:
  u1,v1,u2,v2=rect
  uv=[(u2/4,v1/2),(u1/4,v1/2),(u1/4,v2/2),(u2/4,v2/2)]
  out.append((name,[(p[i],a) for i,a in zip(ix,uv)]))
 return out

def transform(p,meta,normal=False):
 x,y,z=p;x,y,z=x,-y,-z
 az={1:-90,2:90,4:180}.get(meta,0); ax={5:0,6:180}.get(meta,90)
 cz,sz=round(math.cos(math.radians(az))),round(math.sin(math.radians(az)))
 cx,sx=round(math.cos(math.radians(ax))),round(math.sin(math.radians(ax)))
 x,y=x*cz-y*sz,x*sz+y*cz;y,z=y*cx-z*sx,y*sx+z*cx
 return tuple(round(a+(0 if normal else 8),7) for a in (x,y,z))

def same(a,b):return all(abs(x-y)<1e-5 for x,y in zip(a,b))

def render_face(face,lo,hi,verts):
 canonical=[tuple((lo,hi)[s][i] for i,s in enumerate(c)) for c in ORDER[face]]
 target=[]
 for p in canonical:
  match=[uv for q,uv in verts if same(p,q)]
  assert len(match)==1,(face,p,verts)
  target.append(match[0])
 us=[x[0] for x in target];vs=[x[1] for x in target]
 for fu,fv,rot in itertools.product([False,True],[False,True],range(4)):
  u1,u2=(max(us),min(us)) if fu else (min(us),max(us))
  v1,v2=(max(vs),min(vs)) if fv else (min(vs),max(vs))
  uv=[(u1,v1),(u1,v2),(u2,v2),(u2,v1)]
  if all(same(uv[(i+rot)%4],target[i]) for i in range(4)):
   r={'uv':[u1,v1,u2,v2],'texture':'#model'}
   if rot:r['rotation']=rot*90
   return r
 raise ValueError((face,target))

def model(kind,meta):
 elements=[]
 for b in BOXES[kind]:
  fs=faces(b); world=[(name,[(transform(p,meta),uv) for p,uv in vs]) for name,vs in fs]
  ps=[p for n,vs in world for p,u in vs];lo=[min(p[i] for p in ps) for i in range(3)];hi=[max(p[i] for p in ps) for i in range(3)]
  output={}
  for source,vs in world:
   n=transform(DIRECTIONS[source],meta,True)
   face=next(k for k,v in DIRECTIONS.items() if same(n,v))
   output[face]=render_face(face,lo,hi,vs)
  e={'from':lo,'to':hi,'shade':False,'faces':output}
  if kind=='firefly' and b[6]==0:e['light_emission']=15
  elements.append(e)
 tex={'cicada':'cicada-model','firefly':'firefly-tiny'}[kind]
 return {'ambientocclusion':False,'textures':{'model':'twilightforest:model/'+tex,'particle':'twilightforest:model/'+tex},'elements':elements}

def main():
 assert hashlib.sha256(SRC.read_bytes()).hexdigest()==PIN
 out=W/'build/visual-resources';out.mkdir(parents=True,exist_ok=True)
 evidence={'originalSha256':PIN,'sourceModelClassSha256':{},'faceAssertions':0,'geometryConstants':BOXES,'topAlphaChecks':{}}
 with ZipFile(SRC) as z:
  for kind,cls in [('cicada','ModelTFCicada'),('firefly','ModelTFFirefly')]:
   p=f'twilightforest/client/model/{cls}.class';evidence['sourceModelClassSha256'][p]=hashlib.sha256(z.read(p)).hexdigest()
   for meta in range(7):
    m=model(kind,meta);p=out/f'legacyforgebridge/rev309/templates/{kind}_{meta}.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(m,separators=(',',':'))+'\n')
    evidence['faceAssertions']+=len(m['elements'])*6
  for kind,ixs in [('cicada',[0,5]),('firefly',[0,3])]:
   tex={'cicada':'cicada-model','firefly':'firefly-tiny'}[kind]
   img=Image.open(BytesIO(z.read(f'assets/twilightforest/textures/model/{tex}.png'))).convert('RGBA')
   for ix in ixs:
    m=model(kind,5);uv=m['elements'][ix]['faces']['up']['uv'];r=[min(uv[0],uv[2])*4,min(uv[1],uv[3])*2,max(uv[0],uv[2])*4,max(uv[1],uv[3])*2]
    a=img.crop(tuple(round(x) for x in r)).getchannel('A');count=sum(v>0 for v in a.getdata());assert count>0,(kind,ix,r)
    evidence['topAlphaChecks'][f'{kind}:{ix}']={'uv':uv,'sourceOpaqueOrTranslucentPixels':count,'sourceRect':r}
 (W/'verification/source-visual-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2))
 print(json.dumps(evidence,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
