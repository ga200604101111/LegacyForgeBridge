import java.io.*;import java.nio.file.*;import java.util.*;import java.util.zip.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;

/** Surgical patch over the exact previous complete artifacts; no dependency bundling. */
public final class PatchUvLayout {
 static final String BUILD="rev314-uv-layout.1";
 static final String SEM="2026-10-10.314-source-modelbox-uv";
 static final String VERSION="0.2.0-alpha.27-corpus4-local.68-rev314-uv-layout.1";
 static final List<String> changes=new ArrayList<>();
 static String map(String owner,String method,String s){
  if(owner.equals("dev/yinghuang/legacyforgebridge/bootstrap/LfbLayout"))return s;
  s=s.replace("legacy-cache","lfb/cache").replace("lfb/bootstrap.log","lfb/logs/bootstrap.log");
  s=s.replace("logs/legacyforgebridge.log","lfb/logs/runtime.log").replace("logs/lfb-motion","lfb/logs/lfb-motion").replace("logs/lfb-s12","lfb/logs/lfb-s12");
  s=s.replace("conversion-diagnostics-rev213","conversion-diagnostics").replace("conversion-timings-rev213","conversion-timings");
  if(s.equals("logs")&&(owner.endsWith("/LegacyFileLogger")||owner.endsWith("/LegacyMotionTraceLog")))s="lfb/logs";
  if(s.equals("legacyforgebridge.log")&&owner.endsWith("/LegacyFileLogger"))s="runtime.log";
  if(s.equals("rev313-bootstrap.1"))s=BUILD;
  if(s.equals("2026-10-09.310-pre-atlas-critter-source-flat-icon"))s=SEM;
  if(s.equals("0.2.0-alpha.27-corpus4-local.67-rev313-critter-visual-completion.1"))s=VERSION;
  if(owner.endsWith("/LegacyFileLogger")&&method.equals("initializeForLaunch")) {
   if(s.startsWith("version="))s="version="+VERSION;
   if(s.startsWith("converterRevision="))s="converterRevision="+SEM;
  }
  return s;
 }
 static Object literal(String owner,String method,Object o){return o instanceof String s?map(owner,method,s):o;}
 static byte[] patchClass(byte[] bytes,boolean runtime)throws Exception {
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);boolean changed=false;
  for(FieldNode f:c.fields){Object n=literal(c.name,"<field>",f.value);if(!Objects.equals(n,f.value)){f.value=n;changed=true;}}
  for(MethodNode m:c.methods){
   for(AbstractInsnNode i:m.instructions){
    if(i instanceof LdcInsnNode l){Object n=literal(c.name,m.name,l.cst);if(!Objects.equals(n,l.cst)){l.cst=n;changed=true;}}
    if(i instanceof InvokeDynamicInsnNode d){for(int k=0;k<d.bsmArgs.length;k++){Object n=literal(c.name,m.name,d.bsmArgs[k]);if(!Objects.equals(n,d.bsmArgs[k])){d.bsmArgs[k]=n;changed=true;}}}
   }
   if(runtime&&c.name.equals("dev/yinghuang/legacyforgebridge/rev311/Rev311CritterRenderer")&&(m.name.equals("part")||m.name.equals("glowSheet"))){
    m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
    String box=c.name+"$ModelBox";
    for(String f:List.of("u","v","x","y","z","w","h","d")){
     m.instructions.add(new VarInsnNode(Opcodes.ALOAD,0));m.instructions.add(new FieldInsnNode(Opcodes.GETFIELD,box,f,(f.equals("x")||f.equals("y")||f.equals("z"))?"F":"I"));
    }
    m.instructions.add(new InsnNode(m.name.equals("glowSheet")?Opcodes.ICONST_1:Opcodes.ICONST_0));
    m.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"dev/yinghuang/legacyforgebridge/visual/LegacyBoxModelPart","create","(IIFFFIIIZ)Lnet/minecraft/class_630;",false));
    m.instructions.add(new InsnNode(Opcodes.ARETURN));m.maxStack=10;m.maxLocals=1;changed=true;
    changes.add("explicit-face-method "+m.name);
   }
   if(runtime&&c.name.equals("dev/yinghuang/legacyforgebridge/rev311/Rev311CritterRenderer")&&m.name.equals("<init>")) {
    for(AbstractInsnNode i:m.instructions.toArray())if(i.getOpcode()==Opcodes.RETURN){
     InsnList log=new InsnList();log.add(new FieldInsnNode(Opcodes.GETSTATIC,"dev/yinghuang/legacyforgebridge/LegacyForgeBridge","LOGGER","Ldev/yinghuang/legacyforgebridge/LegacyFileLogger;"));
     log.add(new LdcInsnNode("LFB CRITTER_UV: explicit source ModelBox faces active; original geometry/texture, no world-model fallback imposed"));
     log.add(new InsnNode(Opcodes.ICONST_0));log.add(new TypeInsnNode(Opcodes.ANEWARRAY,"java/lang/Object"));
     log.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL,"dev/yinghuang/legacyforgebridge/LegacyFileLogger","info","(Ljava/lang/String;[Ljava/lang/Object;)V",false));m.instructions.insertBefore(i,log);m.maxStack=Math.max(3,m.maxStack);changed=true;
    }
   }
  }
  if(!changed)return bytes;
  ClassWriter cw=new ClassWriter(0);c.accept(cw);changes.add(c.name);return cw.toByteArray();
 }
 static byte[] jar(byte[] original,boolean runtime,Map<String,byte[]> additions)throws Exception {
  TreeMap<String,byte[]> content=new TreeMap<>();
  try(ZipInputStream in=new ZipInputStream(new ByteArrayInputStream(original))){for(ZipEntry e;(e=in.getNextEntry())!=null;){if(content.containsKey(e.getName()))throw new IOException("duplicate ZIP "+e.getName());if(!e.isDirectory())content.put(e.getName(),in.readAllBytes());}}
  for(var e:content.entrySet()){
   String n=e.getKey();byte[] b=e.getValue();
   if(n.endsWith(".class"))e.setValue(patchClass(b,runtime));
   else if(n.endsWith(".jar")&&n.contains("helper"))e.setValue(jar(b,false,Map.of()));
   else if(n.equals("fabric.mod.json")){String s=new String(b,java.nio.charset.StandardCharsets.UTF_8);s=s.replace("0.2.0-alpha.27-corpus4-local.67-rev313-critter-visual-completion.1",VERSION);e.setValue(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
  }
  content.putAll(additions);ByteArrayOutputStream bytes=new ByteArrayOutputStream();
  try(ZipOutputStream out=new ZipOutputStream(bytes)){out.setLevel(9);for(var e:content.entrySet()){ZipEntry entry=new ZipEntry(e.getKey());entry.setTimeLocal(java.time.LocalDateTime.of(2000,1,1,0,0));out.putNextEntry(entry);out.write(e.getValue());out.closeEntry();}}
  return bytes.toByteArray();
 }
 public static void main(String[] a)throws Exception{
  Path input=Path.of(a[0]),output=Path.of(a[1]);boolean runtime=Boolean.parseBoolean(a[2]);Map<String,byte[]> extra=new TreeMap<>();
  for(int i=3;i<a.length;i++){Path root=Path.of(a[i]);try(var stream=Files.walk(root)){for(Path p:stream.filter(Files::isRegularFile).toList())extra.put(root.relativize(p).toString().replace('\\','/'),Files.readAllBytes(p));}}
  Files.write(output,jar(Files.readAllBytes(input),runtime,extra));for(String c:changes)System.out.println(c);
 }
}
