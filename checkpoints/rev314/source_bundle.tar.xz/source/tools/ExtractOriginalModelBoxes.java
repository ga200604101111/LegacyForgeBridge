import java.nio.file.*;import java.util.*;import java.util.jar.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
/** Reads verified source constructor constants only. Never defines source classes. */
public class ExtractOriginalModelBoxes {
 static AbstractInsnNode prev(AbstractInsnNode n){do{n=n.getPrevious();}while(n!=null&&n.getOpcode()<0);return n;}
 static Number number(AbstractInsnNode n){int o=n.getOpcode();if(n instanceof LdcInsnNode l&&l.cst instanceof Number k)return k;if(n instanceof IntInsnNode i)return i.operand;if(o>=Opcodes.ICONST_M1&&o<=Opcodes.ICONST_5)return o-Opcodes.ICONST_0;if(o>=Opcodes.FCONST_0&&o<=Opcodes.FCONST_2)return (float)(o-Opcodes.FCONST_0);throw new IllegalStateException("Nonconstant box argument: "+n);}
 public static void main(String[] a)throws Exception{StringBuilder j=new StringBuilder("{");try(JarFile z=new JarFile(a[0])){boolean first=true;for(String name:List.of("ModelTFCicada","ModelTFFirefly")){
  ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getJarEntry("twilightforest/client/model/"+name+".class"))).accept(c,0);
  Map<String,List<Number>> uv=new LinkedHashMap<>();List<List<Number>> boxes=new ArrayList<>();
  for(MethodNode m:c.methods)if(m.name.equals("<init>"))for(AbstractInsnNode n:m.instructions){
   if(n instanceof FieldInsnNode f&&f.getOpcode()==Opcodes.PUTFIELD&&f.desc.equals("Lnet/minecraft/client/model/ModelRenderer;")){
    AbstractInsnNode call=prev(n);if(!(call instanceof MethodInsnNode init)||!init.desc.equals("(Lnet/minecraft/client/model/ModelBase;II)V"))throw new IllegalStateException("Unexpected model initialization");
    Number v=number(prev(call)),u=number(prev(prev(call)));uv.put(f.name,List.of(u,v));
   }
   if(n instanceof MethodInsnNode call&&call.name.equals("func_78790_a")&&call.desc.equals("(FFFIIIF)V")){
    List<Number> b=new ArrayList<>();AbstractInsnNode p=n;for(int k=0;k<7;k++){p=prev(p);b.add(number(p));}Collections.reverse(b);
    if(b.removeLast().floatValue()!=0)throw new IllegalStateException("Unexpected inflation");p=prev(p);if(!(p instanceof FieldInsnNode f)||!uv.containsKey(f.name))throw new IllegalStateException("Unknown source receiver");
    ArrayList<Number> full=new ArrayList<>(uv.get(f.name));full.addAll(b);boxes.add(full);
   }
  }
  if(!first)j.append(',');first=false;j.append('"').append(name).append("\":").append(boxes);
 }}j.append('}');Files.writeString(Path.of(a[1]),j);System.out.println(j);}
}
