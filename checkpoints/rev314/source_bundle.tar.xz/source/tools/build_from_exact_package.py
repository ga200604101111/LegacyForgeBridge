"""Rebuild the delta from the exact previous delivered package (not root GitHub src).
Requires JDK21, Python3, Pillow, and ASM core/tree/analysis on a build-only classpath.
Local compile signatures are explicit API test doubles; none enter output JARs.
"""
from pathlib import Path
from zipfile import ZipFile
import argparse,os,shutil,subprocess,sys,json,hashlib
PIN='d6f0df8e96f3ca43657a4c4509d57769cf837081373c5aa3946e32a051119d16'
SOURCE='1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589'
ROOT=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--base-package',required=True,type=Path);a.add_argument('--source-jar',required=True,type=Path);a.add_argument('--asm-classpath',required=True);a.add_argument('--out',required=True,type=Path);args=a.parse_args()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(args.base_package)!=PIN:raise SystemExit('Exact previous Linkage_Audit installer SHA mismatch; do not patch a different base')
if sha(args.source_jar)!=SOURCE:raise SystemExit('Exact user-supplied Twilight Forest source SHA mismatch')
work=args.out.resolve()
if work.exists() and any(work.iterdir()):raise SystemExit('Output directory must be absent or empty')
work.mkdir(parents=True,exist_ok=True)
shutil.copytree(ROOT/'src',work/'src')
(work/'tools').mkdir();(work/'verification').mkdir();(work/'build').mkdir()
for n in ['generate_visual.py','PatchUvLayout.java']:shutil.copyfile(ROOT/'tools'/n,work/'tools'/n)
signatures=ROOT/'api-signatures'
if not signatures.exists():signatures=ROOT/'build/api-signatures'
shutil.copytree(signatures,work/'api-signatures')
base=work/'base';base.mkdir();payload=work/'build/LFB_Package';payload.mkdir(parents=True)
names=['LFB-Bootstrap.jar','LFB-Converter.jar','LegacyForgeBridge-rev313-bootstrap1.jar']
with ZipFile(args.base_package) as z:
 for name in names:(base/name).write_bytes(z.read('lfb_install/LFB_Package/'+name))
env={**os.environ,'LC_ALL':'C.UTF-8','LANG':'C.UTF-8','LFB_TF_SOURCE':str(args.source_jar.resolve())}
def run(cmd,log=None):
 p=subprocess.run(list(map(str,cmd)),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 if log:(work/'verification'/log).write_text(p.stdout)
 if p.returncode:raise SystemExit(p.stdout)
 if not log:print(p.stdout,end='')
def javac(out,files,cp=None):
 target=work/'build'/out;target.mkdir()
 run(['javac','-encoding','UTF-8','--release','21',*(['-cp',cp] if cp else []),'-d',target,*files]);return target
run([sys.executable,work/'tools/generate_visual.py'],'generated-visual.log')
boot=javac('bootstrap-classes',sorted((work/'src/dev/yinghuang/legacyforgebridge/bootstrap').glob('*.java')),str(base/names[0]))
sig=javac('signature-classes',sorted((work/'api-signatures').rglob('*.java')))
vis=javac('visual-classes',sorted((work/'src/dev/yinghuang/legacyforgebridge/visual').glob('*.java')),str(sig))
patch=javac('patch-tool',[work/'tools/PatchUvLayout.java'],args.asm_classpath)
for name,runtime,extra in [(names[0],'false',[boot]),(names[1],'false',[work/'build/visual-resources']),(names[2],'true',[vis,work/'build/visual-resources'])]:
 run(['java','-cp',str(patch)+os.pathsep+args.asm_classpath,'PatchUvLayout',base/name,payload/name,runtime,*extra],name+'.changes.log')
(payload/'bundle.properties').write_text('build=rev314-uv-layout.1\ncoreSha256='+sha(payload/names[1])+'\nruntimeSha256='+sha(payload/names[2])+'\n')
(payload/'checksums.json').write_text(json.dumps({'files':[{'name':p.name,'sha256':sha(p)} for p in sorted(payload.iterdir()) if p.name!='checksums.json']},indent=2))
print('Rebuilt payload:',payload)
