import java.nio.file.*;import java.util.jar.*;import jdk.internal.org.objectweb.asm.*;
public class MakeAnnotationFixture implements Opcodes{
 public static void main(String[] a)throws Exception{ClassWriter w=new ClassWriter(0);w.visit(V1_7,ACC_PUBLIC,"fixture/NoExecute",null,"java/lang/Object",null);AnnotationVisitor v=w.visitAnnotation("Lcpw/mods/fml/common/Mod;",true);v.visit("modid",a.length>1?a[1]:"fixture");v.visit("name","Annotation-only test source");v.visit("version","1.0");if(a.length>2)v.visit("dependencies",a[2]);v.visitEnd();
  MethodVisitor m=w.visitMethod(ACC_STATIC,"<clinit>","()V",null,null);m.visitCode();m.visitTypeInsn(NEW,"java/lang/AssertionError");m.visitInsn(DUP);m.visitLdcInsn("TEST_FAIL_ORIGINAL_FORGE_CLASS_EXECUTED");m.visitMethodInsn(INVOKESPECIAL,"java/lang/AssertionError","<init>","(Ljava/lang/Object;)V",false);m.visitInsn(ATHROW);m.visitMaxs(3,0);m.visitEnd();w.visitEnd();
  try(JarOutputStream z=new JarOutputStream(Files.newOutputStream(Path.of(a[0])))){z.putNextEntry(new JarEntry("fixture/NoExecute.class"));z.write(w.toByteArray());z.closeEntry();z.putNextEntry(new JarEntry("assets/fixture/lang/en_US.lang"));z.write("fixture.label=Test value\n".getBytes());z.closeEntry();}
 }
}
