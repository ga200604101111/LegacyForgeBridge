import java.nio.file.*;import java.util.*;import dev.yinghuang.legacyforgebridge.bootstrap.*;
public class GateProbe {
 public static void main(String[] a)throws Exception{
  switch(a[0]){
   case "gate" -> {RuntimeGate.verifyFiles(Path.of(a[1]),Path.of(a[2]));RuntimeGate.initialized();System.out.println("GATE_OK");System.out.flush();if(a.length>3)Thread.sleep(Long.parseLong(a[3]));}
   case "lock" -> {try(var l=Support.lock(Path.of(a[1]))){System.out.println("LOCK_OK");System.out.flush();Thread.sleep(Long.parseLong(a[2]));}}
   case "set" -> {Properties p=Support.load(Path.of(a[1]));for(int i=2;i<a.length;i+=2)p.setProperty(a[i],a[i+1]);Support.save(Path.of(a[1]),p);}
   case "get" -> {System.out.print(Support.load(Path.of(a[1])).getProperty(a[2],""));}
   case "scoped" -> {System.out.println(Support.scoped(Path.of(a[1]),a[2]));}
   default -> throw new IllegalArgumentException();
  }
 }
}
