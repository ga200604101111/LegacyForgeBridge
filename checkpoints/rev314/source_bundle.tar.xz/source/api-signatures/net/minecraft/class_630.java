package net.minecraft;import java.util.*;import org.joml.Vector3fc; public class class_630 {
 public final List<class_628> cubes;public class_630(List<class_628> c,Map<String,class_630> children){cubes=c;}
 public static record class_618(float x,float y,float z,float u,float v){}
 public static record class_593(class_618[] vertices,Vector3fc direction){}
 public static class class_628 {public final class_593[] field_3649=new class_593[6];public class_628(int u,int v,float x,float y,float z,float w,float h,float d,float dx,float dy,float dz,boolean mirror,float tw,float th,Set<class_2350> s){} }
}