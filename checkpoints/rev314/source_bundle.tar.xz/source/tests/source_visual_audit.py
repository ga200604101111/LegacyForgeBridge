"""Original-JAR bytecode + actual packaged pre-atlas pass, not a live rendering test.
The pre-atlas registry context is a controlled fixture with arbitrary target IDs.
"""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
from PIL import Image
import hashlib, importlib.util, json, os, shutil, subprocess
W=Path(__file__).resolve().parents[1]
SRC=Path(os.environ.get('LFB_TF_SOURCE','/mnt/data/twilightforest-1.7.10-2.3.8-tw.jar'))
spec=importlib.util.spec_from_file_location('visual',W/'tools/generate_visual.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
assert hashlib.sha256(SRC.read_bytes()).hexdigest()==v.PIN
r=json.loads((W/'verification/original-model-boxes.json').read_text());checks=[]
def check(name,yes):
    assert yes,name
    checks.append(name)
for kind,cls in [('cicada','ModelTFCicada'),('firefly','ModelTFFirefly')]:
    check('ASM original box constants '+kind,[list(x) for x in v.BOXES[kind]]==r[cls])
results={'scope':'Original model constructor inspection and real packaged pre-atlas method; controlled converted-content fixture; no game renderer','sourceSha256':v.PIN,'changes':{}}
with ZipFile(SRC) as source:
    assets={n:source.read(n) for n in source.namelist() if n.startswith('assets/twilightforest/') and not n.endswith('/')}
    image_map={kind:Image.open(BytesIO(assets['assets/twilightforest/textures/model/'+tex+'.png'])).convert('RGBA') for kind,tex in [('cicada','cicada-model'),('firefly','firefly-tiny')]}
    for variant,core in [('old',W/'base/lfb_install/LFB_Package/LFB-Converter.jar'),('new',W/'build/LFB_Package/LFB-Converter.jar')]:
        root=W/'verification'/('visual-stage-'+variant)
        if root.exists():shutil.rmtree(root)
        for name,b in assets.items():p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
        p=root/'legacyforgebridge/converted-content.json';p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(json.dumps({'sourceSha256':v.PIN,'blocks':[{'sourceClass':'twilightforest/block/BlockTF'+c,'id':'twilightforest:test_'+k} for k,c in [('cicada','Cicada'),('firefly','Firefly')]],'items':[]}))
        env={**os.environ,'LC_ALL':'C.UTF-8','LANG':'C.UTF-8'}
        proc=subprocess.run(['java','-Xverify:all','-cp',os.pathsep.join(map(str,[W/'tests',core,W/'lib/gson-texplate.jar'])),'PreAtlasProbe',str(root)],env=env,capture_output=True,text=True,timeout=30)
        (W/'verification'/('pre-atlas-'+variant+'.log')).write_text(proc.stdout+proc.stderr)
        check('Packaged pre-atlas returned '+variant,proc.returncode==0 and 'PREATLAS_EXECUTED' in proc.stdout)
        for k in ['cicada','firefly']:
            for meta in range(7):
                model=json.loads((root/f'assets/twilightforest/models/block/test_{k}_lfb_critter_{meta}.json').read_text())
                if variant=='new':
                    want=v.model(k,meta)
                    check(f'exact source UV templates {k}:{meta}',model['elements']==want['elements'])
                    check(f'source geometry part count {k}:{meta}',len(model['elements'])==len(v.BOXES[k]))
            item=json.loads((root/f'assets/twilightforest/models/item/test_{k}.json').read_text())
            check(f'flat inventory model retained {variant}:{k}',item['parent']=='minecraft:item/generated')
            for n in ['cicada-model','firefly-tiny']:
                a=f'assets/twilightforest/textures/model/{n}.png';check(f'original model texture unchanged {variant}:{k}:{n}',(root/a).read_bytes()==assets[a])
            if k=='cicada':
                floor=json.loads((root/f'assets/twilightforest/models/block/test_{k}_lfb_critter_5.json').read_text())
                for ix,label in [(0,'legs'),(5,'wings')]:
                    uv=floor['elements'][ix]['faces']['up']['uv'];box=(min(uv[0],uv[2])*4,min(uv[1],uv[3])*2,max(uv[0],uv[2])*4,max(uv[1],uv[3])*2)
                    alpha=image_map[k].crop(tuple(round(t) for t in box)).getchannel('A');nonzero=sum(x>0 for x in alpha.getdata())
                    results['changes'][variant+'_'+label]={'worldFace':'up','uv':uv,'originalTexturePixelBounds':box,'nonzeroAlphaPixels':nonzero}
    check('old wings upper face samples transparent region',results['changes']['old_wings']['nonzeroAlphaPixels']==0)
    check('old legs upper face samples transparent region',results['changes']['old_legs']['nonzeroAlphaPixels']==0)
    check('new wings upper face samples original opaque wing',results['changes']['new_wings']['nonzeroAlphaPixels']==40)
    check('new legs upper face samples original opaque legs',results['changes']['new_legs']['nonzeroAlphaPixels']==8)
results['checks']=checks;results['passed']=len(checks)
(W/'verification/source-visual-audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('PASS',len(checks),'source visual checks; old alpha 0/0 -> corrected wings 40, legs 8. No live-game claim.')
