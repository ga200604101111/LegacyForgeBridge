import dev.yinghuang.legacyforgebridge.visual.*;import java.util.*;
/** Production mesh/factory run against declared game-signature test doubles only. */
public final class VisualContractTest {
 static int checks; static void c(boolean b,String m){if(!b)throw new AssertionError(m);checks++;}
 public static void main(String[] a){
  float[][] boxes={{0,21,-4,7.9f,-5,8,1,9},{0,11,-2,6,-4,4,2,6},{0,0,-1,7,-5,2,1,8},{20,15,1,5,2,2,2,2},{20,15,-3,5,2,2,2,2},{20,0,-4,5,-7,8,1,8},{0,21,-4,7.9f,-5,8,1,10},{20,0,-5,5.9f,-9,10,0,10}};
  for(float[] b:boxes){var part=LegacyBoxModelPart.create((int)b[0],(int)b[1],b[2],b[3],b[4],(int)b[5],(int)b[6],(int)b[7],b[6]==0);
   c(part.cubes.size()==1,"one source box");var faces=part.cubes.getFirst().field_3649;c(faces.length==6,"six source faces");
   for(var face:faces){c(face.vertices().length==4,"quad vertex count");float nx=face.direction().x(),ny=face.direction().y(),nz=face.direction().z();c(Math.abs(nx*nx+ny*ny+nz*nz-1)<1e-7,"unit normal");
    for(var p:face.vertices()){c(Float.isFinite(p.x()+p.y()+p.z()+p.u()+p.v()),"finite geometry");c(p.u()>=0&&p.u()<=1&&p.v()>=0&&p.v()<=1,"source UV in 64x32");}
   }
   var top=faces[2];c(top.direction().y()==-1,"legacy top is negative model Y");
   c(Math.abs(top.vertices()[0].u()-(b[0]+b[7]+b[5])/64)<1e-6,"top exact U2");
   c(Math.abs(top.vertices()[0].v()-b[1]/32)<1e-6,"top exact V1");
   c(Math.abs(top.vertices()[0].y()-b[3])<1e-6,"top exact height");
  }
  try{LegacyBoxMesh.create(0,0,0,0,0,1,1,1,1,0,32);throw new AssertionError("zero texture allowed");}catch(IllegalArgumentException e){checks++;}
  System.out.println("TOTAL "+checks+" PASS — production face factory; game geometry API doubles, not a rendered Minecraft test");
 }
}
