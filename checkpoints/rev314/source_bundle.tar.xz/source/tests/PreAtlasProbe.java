import java.nio.file.*;
public class PreAtlasProbe {public static void main(String[] a)throws Exception {dev.yinghuang.legacyforgebridge.rev310.Rev310CritterPreAtlas.process(Path.of(a[0]));System.out.println("PREATLAS_EXECUTED");}}
