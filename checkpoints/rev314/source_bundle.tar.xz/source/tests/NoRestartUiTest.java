package dev.yinghuang.legacyforgebridge.bootstrap;
import dev.yinghuang.legacyforgebridge.desktop.*;
import java.nio.file.*;import java.util.*;import java.io.*;import java.lang.reflect.*;
import java.awt.*;import java.awt.event.*;import javax.swing.*;import javax.imageio.ImageIO;import java.util.concurrent.atomic.*;
public final class NoRestartUiTest {
 static int checks;static JFrame frame;static Path out;
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);System.out.println("PASS "+(++checks)+" "+message);}
 static void flush()throws Exception{Thread.sleep(650);for(int i=0;i<5;i++)SwingUtilities.invokeAndWait(()->{});}
 static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static void invoke(Object o,String n)throws Exception{Method m=o.getClass().getDeclaredMethod(n);m.setAccessible(true);m.invoke(o);}
 static void shot(String n)throws Exception{AtomicReference<Rectangle> r=new AtomicReference<>();SwingUtilities.invokeAndWait(()->r.set(frame.getBounds()));ImageIO.write(new Robot().createScreenCapture(r.get()),"png",out.resolve(n+".png").toFile());}
 static String label(String n)throws Exception{AtomicReference<String> r=new AtomicReference<>();SwingUtilities.invokeAndWait(()->{JLabel l=OriginalDesktopUi.find(frame.getContentPane(),n,JLabel.class);r.set(l==null?null:l.getText());});return r.get();}
 static void noRestartText(Component c){String s=c instanceof AbstractButton b?b.getText():c instanceof JLabel l?l.getText():c instanceof javax.swing.text.JTextComponent t?t.getText():"";if(s!=null)for(String bad:new String[]{"自動重啟","自动重启","自動退出","自动退出","倒數","倒数","restart.cancel","取消本次啟動"})if(s.contains(bad))throw new AssertionError("Old control visible: "+s);if(c instanceof Container d)for(Component child:d.getComponents())noRestartText(child);}
 static void rejectLegacyCommand(PrismTarget target,boolean activation)throws Exception{try{if(activation)target.activationCommand();else target.command();throw new AssertionError("Legacy command allowed");}catch(UnsupportedOperationException expected){check(true,activation?"legacy activation command rejected":"legacy launch command rejected");}}
 public static void main(String[] args){try{run(args);}catch(Throwable t){t.printStackTrace();System.exit(1);}}
 public static void run(String[] args)throws Exception{
  out=Path.of(args[0]).toAbsolutePath();Files.createDirectories(out);Path game=out.resolve("測試 Program Files/minecraft");
  Files.createDirectories(game.resolve("mods"));Files.createDirectories(game.resolve("old-mods"));
  Files.writeString(game.resolve("options.txt"),"lang:zh_tw\n");Files.write(game.resolve("old-mods/測試模組.jar"),new byte[0]);
  ProgressModel m=new ProgressModel(game);
  try(OriginalDesktopUi ui=new OriginalDesktopUi(game,m)){
   flush();frame=(JFrame)field(ui,"frame");check(frame!=null,"real original helper window constructed");
   check(frame.isShowing(),"window visible under Xvfb");check(!frame.getIconImages().isEmpty(),"original icon installed");
   JButton old=(JButton)field(ui,"cancel");
   check(old.getParent()==null&&!old.isShowing()&&!old.isEnabled(),"former restart button absent from layout and disabled");
   check(old.getActionListeners().length==0,"former restart button has zero action listeners");
   SwingUtilities.invokeAndWait(()->{noRestartText(frame.getContentPane());old.doClick();});
   check(!m.isCanceled(),"detached compatibility button cannot cancel or restart");
   check(OriginalDesktopUi.find(frame.getContentPane(),"conversion-progress",JProgressBar.class)!=null,"original progress bar present");
   check(Boolean.TRUE.equals(frame.getRootPane().getClientProperty("lfb.bootstrap.original-ui")),"external binding marked");
   check("removed".equals(frame.getRootPane().getClientProperty("lfb.bootstrap.restart-controls")),"restart removal build active");
   m.accept("[LFB] CONVERT_START 測試模組.jar sourceSha256="+"a".repeat(64));
   m.accept("2026-10-10T00:00:00Z [LFB INFO] PASS 61/121 LegacyLanguagePass");flush();
   check(m.snapshot().getProperty("source").equals("測試模組.jar"),"real CONVERT_START event sets source");
   check(m.snapshot().getProperty("percent").equals("49"),"progress from completed pass count");
   AtomicInteger bar=new AtomicInteger();SwingUtilities.invokeAndWait(()->bar.set(OriginalDesktopUi.find(frame.getContentPane(),"conversion-progress",JProgressBar.class).getValue()));
   check(bar.get()==49,"original bar reflects model progress");
   check(label("lfb.rev300.current-module").contains("測試模組"),"current module label updates");
   check(frame.getTitle().contains("LegacyForgeBridge")&&frame.getTitle().contains("YingHunag09"),"title format and author retained");
   check(label("lfb.rev300.resource-usage").contains("RAM"),"memory/CPU row updates");
   JButton support=OriginalDesktopUi.find(frame.getContentPane(),"supported-mods-button",JButton.class);
   JButton diagnostics=OriginalDesktopUi.find(frame.getContentPane(),"lfb-conversion-diagnostics-button",JButton.class);
   check(diagnostics!=null&&diagnostics.getText().equals("轉換診斷"),"remaining diagnostic button localizes with one-button layout");
   check(support!=null,"original support button retained in details");
   SwingUtilities.invokeAndWait(()->noRestartText(frame.getContentPane()));check(true,"no restart or countdown controls in converting view");shot("01-converting-no-restart");
   SwingUtilities.invokeAndWait(()->OriginalDesktopUi.find(frame.getContentPane(),"details-toggle",JToggleButton.class).doClick());flush();
   check(((JTextArea)field(ui,"results")).isShowing(),"details expansion works");shot("02-details-no-restart");
   SwingUtilities.invokeLater(support::doClick);flush();
   AtomicReference<JDialog> dialog=new AtomicReference<>();SwingUtilities.invokeAndWait(()->{for(Window w:frame.getOwnedWindows())if(w instanceof JDialog d&&d.isVisible())dialog.set(d);});
   check(dialog.get()!=null,"original diagnostic/support dialog opens");
   SwingUtilities.invokeAndWait(()->dialog.get().dispose());flush();
   m.accept("2026-10-10T00:00:00Z [LFB INFO] PASS_RESULT LegacyLanguagePass ok=true ms=45");
   check(m.snapshot().getProperty("percent").equals("50"),"pass completion advances counter");
   m.accept("[LFB] PREPARE_OK converted=1 reused=0 enabled=1 gameStarted=false");
   check(!m.isTerminal()&&m.snapshot().getProperty("percent").equals("99"),"log alone never authorizes success");
   Object helper=field(ui,"helper");Path session=(Path)field(ui,"session");
   Properties malicious=m.snapshot();malicious.setProperty("autoRestart","true");malicious.setProperty("state","COUNTDOWN");
   Support.save(session.resolve("status.properties"),malicious);
   invoke(helper,"poll");invoke(helper,"cancelAutomatic");
   check(!Files.exists(session.resolve("cancel.properties")),"legacy poll and cancel hooks produce no restart signal even with old status");
   check(!(Boolean)field(helper,"launched"),"legacy poll cannot launch Prism");
   m.complete(1,new IOException("測試錯誤：無法讀取指定來源；TEST ONLY"));flush();
   check(m.snapshot().getProperty("state").equals("ERROR"),"failure not promoted to DONE");
   SwingUtilities.invokeAndWait(()->noRestartText(frame.getContentPane()));check(true,"no restart/countdown controls in error view");
   check(old.getParent()==null&&old.getActionListeners().length==0,"updates never restore the old button");
   shot("03-error-no-restart");
   SwingUtilities.invokeAndWait(()->frame.dispatchEvent(new WindowEvent(frame,WindowEvent.WINDOW_CLOSING)));
   check(((java.util.concurrent.CountDownLatch)field(ui,"dismissed")).getCount()==0,"native window close dismisses terminal errors");ui.finishDisplay(1);
  }
  check(!frame.isDisplayable(),"UI disposed without legacy restart");
  Properties p=Support.load(game.resolve("lfb/bootstrap-ui.properties"));check(p.getProperty("gameStarted").equals("false"),"UI never claims game launched");
  check(p.getProperty("autoRestart").equals("false"),"autoRestart is always false in generated status");
  check(!Files.exists(game.resolve("lfb/cache/desktop/current.properties")),"no old restart session is published");
  check(!Files.exists(game.resolve(Support.TICKET)),"UI-only test cannot create launch ticket");
  try{DesktopHelper.main(new String[]{game.toString()});throw new AssertionError("Legacy main accepted");}catch(UnsupportedOperationException expected){check(true,"obsolete standalone helper entrypoint rejects execution");}
  PrismTarget target=new PrismTarget(game.resolve("unused.exe"),game,"test",game,"unused");rejectLegacyCommand(target,false);rejectLegacyCommand(target,true);
  for(boolean warn:new boolean[]{false,true}){
   ProgressModel fresh=new ProgressModel(game);
   try(OriginalDesktopUi ui=new OriginalDesktopUi(game,fresh)){
    flush();frame=(JFrame)field(ui,"frame");if(warn)fresh.accept("2026-10-10T00:00:00Z [LFB WARN] TEST partial support");
    check(fresh.complete(0,null)==0,"successful worker returns zero "+(warn?"with warning":"without warning"));flush();
    SwingUtilities.invokeAndWait(()->noRestartText(frame.getContentPane()));check(true,"terminal view contains no restart controls "+(warn?"WARN":"DONE"));
    shot(warn?"05-warning-no-restart":"04-done-no-restart");
    long start=System.nanoTime();ui.finishDisplay(0);check(System.nanoTime()-start<3_000_000_000L,"success releases host without a restart countdown");
   }
  }
  ProgressModel canceled=new ProgressModel(game);canceled.requestCancel();check(canceled.complete(0,null)==2,"manual cancellation still blocks launch after safe completion");
  check(canceled.snapshot().getProperty("state").equals("ERROR"),"manual cancellation not reported as success");
  System.out.println("TOTAL "+checks+" PASS");System.exit(0);
 }
}
