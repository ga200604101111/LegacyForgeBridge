import dev.yinghuang.legacyforgebridge.bootstrap.*;
import java.nio.file.*;import java.util.*;import java.io.*;
/** Exercises actual packaged migration against disposable directories, including conflicts. */
public final class LayoutTest {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;System.out.println("PASS "+s);}
 static void put(Path p,String s)throws Exception{Files.createDirectories(p.getParent());Files.writeString(p,s);}
 static void run(Path g)throws Exception{try(var lock=Support.lock(g)){LfbLayout.prepare(g);}}
 public static void main(String[] a)throws Exception{
  Path root=Path.of(a[0]).toAbsolutePath();Files.createDirectories(root);Path g=root.resolve("Program Files 中文/instance/minecraft");Files.createDirectories(g);
  put(g.resolve("old-mods/Original.jar"),"read only source");put(g.resolve("mods/normal.jar"),"read only normal");put(g.resolve(".fabric/remappedJars/keep.jar"),"mapping cache");put(g.resolve("logs/latest.log"),"Minecraft log");
  put(g.resolve("legacy-cache/converted/A-lfb.jar"),"candidate bytes");put(g.resolve("legacy-cache/reports/old.json"),"{\"history\":\"legacy-cache/reports/old.json\"}");
  put(g.resolve("legacy-cache/conversion-state.json"),"{\"candidatePath\":\"legacy-cache/converted/A-lfb.jar\",\"sha\":\"abc\",\"status\":\"PARTIAL\"}");
  Properties p=new Properties();p.setProperty("path","legacy-cache\\converted\\A-lfb.jar");p.setProperty("hash","identity");Support.save(g.resolve("legacy-cache/index.properties"),p);
  put(g.resolve("lfb/bootstrap.log"),"before migration bootstrap");put(g.resolve("logs/legacyforgebridge.log"),"before migration runtime");put(g.resolve("logs/lfb-motion/sample.log"),"motion evidence");
  run(g);
  check(!Files.exists(g.resolve("legacy-cache")),"old cache directory moved");
  check(Files.readString(g.resolve("lfb/cache/converted/A-lfb.jar")).equals("candidate bytes"),"candidate bytes preserved");
  check(Files.readString(g.resolve("lfb/cache/conversion-state.json")).contains("lfb/cache/converted"),"live JSON paths updated");
  check(Files.readString(g.resolve("lfb/cache/conversion-state.json")).contains("PARTIAL"),"support status not upgraded");
  check(Support.load(g.resolve("lfb/cache/index.properties")).getProperty("path").equals("lfb/cache/converted/A-lfb.jar"),"Windows escaped property path migrated");
  check(Support.load(g.resolve("lfb/cache/index.properties")).getProperty("hash").equals("identity"),"fingerprint fields not changed");
  check(Files.readString(g.resolve("lfb/cache/reports/old.json")).contains("legacy-cache/"),"historical report text untouched");
  check(Files.readString(g.resolve("old-mods/Original.jar")).equals("read only source"),"original untouched");
  check(Files.readString(g.resolve("mods/normal.jar")).equals("read only normal"),"normal mod untouched");
  check(Files.readString(g.resolve(".fabric/remappedJars/keep.jar")).equals("mapping cache"),"Fabric cache untouched");
  check(Files.readString(g.resolve("logs/latest.log")).equals("Minecraft log"),"Minecraft log untouched");
  check(!Files.exists(g.resolve("lfb/bootstrap.log")),"old bootstrap log archived");
  check(!Files.exists(g.resolve("logs/legacyforgebridge.log")),"old runtime log archived");
  check(Files.readString(g.resolve("lfb/logs/lfb-motion/sample.log")).equals("motion evidence"),"motion capture moved intact");
  try(var s=Files.list(g.resolve("lfb/logs/archive"))){check(s.count()==2,"both old process logs retained separately");}
  check(Files.readString(g.resolve("lfb/logs/layout-migration.log")).contains("Moved legacy-cache"),"migration report written");
  check(Support.load(g.resolve("lfb/layout.properties")).getProperty("schema").equals("2"),"layout schema recorded");
  String state=Support.sha(g.resolve("lfb/cache/conversion-state.json")),candidate=Support.sha(g.resolve("lfb/cache/converted/A-lfb.jar"));run(g);
  check(Support.sha(g.resolve("lfb/cache/conversion-state.json")).equals(state),"warm layout is idempotent");
  check(Support.sha(g.resolve("lfb/cache/converted/A-lfb.jar")).equals(candidate),"warm candidate unchanged");
  put(g.resolve("lfb/logs/runtime.log"),"runtime generation");run(g);
  check(Files.readString(g.resolve("lfb/logs/runtime.previous.log")).equals("runtime generation"),"runtime previous generation retained");
  // An interrupted/partially migrated tree must preserve both conflicting versions.
  put(g.resolve("legacy-cache/converted/A-lfb.jar"),"old conflict data");put(g.resolve("legacy-cache/converted/B-lfb.jar"),"newly migrated");run(g);
  check(Files.readString(g.resolve("lfb/cache/converted/A-lfb.jar")).equals("candidate bytes"),"new tree not overwritten on conflict");
  check(Files.readString(g.resolve("lfb/cache/converted/B-lfb.jar")).equals("newly migrated"),"missing file merged");
  boolean found=false;try(var s=Files.walk(g.resolve("lfb/backups"))){for(Path f:s.filter(Files::isRegularFile).toList())if(Files.readString(f).equals("old conflict data"))found=true;}
  check(found,"old conflicting data kept in backup");check(!Files.exists(g.resolve("legacy-cache")),"partial merge finishes without leftover old directory");
  // Linked paths are never followed or deleted.
  Path bad=root.resolve("bad/minecraft"),outside=root.resolve("outside");Files.createDirectories(bad.resolve("legacy-cache"));Files.createDirectories(outside);put(outside.resolve("secret.txt"),"leave alone");
  try{Files.createSymbolicLink(bad.resolve("legacy-cache/linked"),outside);try{run(bad);throw new AssertionError("symlink accepted");}catch(IOException expected){check(true,"linked cache tree rejected");}check(Files.readString(outside.resolve("secret.txt")).equals("leave alone"),"outside files preserved");}catch(UnsupportedOperationException e){System.out.println("SKIP symlink not supported");}
  System.out.println("TOTAL "+n+" PASS");
 }
}
