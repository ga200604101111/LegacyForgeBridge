"""Runs real packaged BootstrapMain/ConversionWorker with explicit local library fixtures.
No Minecraft, Fabric, Via, or original server is executed. Includes real disk transaction and JVM-lock tests.
"""
import pathlib,subprocess,os,json,zipfile,hashlib,shutil,time
W=pathlib.Path(__file__).parent;PKG=W/'package/LFB_Package';ROOT=W/'tests'/'Regression Program Files 中文';G=ROOT/'instances'/'分身2 test'/'minecraft';OUT=W/'verification';OUT.mkdir(exist_ok=True)
ENV={**os.environ,'LC_ALL':'C.UTF-8'};RUNTIME=G/'mods/LegacyForgeBridge-rev313-bootstrap1.jar';results=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(name,cond=True,detail=''):
 results.append({'name':name,'passed':bool(cond),'detail':detail});print(('PASS ' if cond else 'FAIL ')+name,flush=True)
 (OUT/'results.json').write_text(json.dumps({'scope':'Packaged code with synthetic sources and local test libraries; no real Minecraft/Fabric/Via server','cases':results},ensure_ascii=False,indent=2))
 if not cond:raise AssertionError(name+': '+detail)
def execute(args,timeout=40):return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=ENV,timeout=timeout)
def probe(*args):return execute(['java','-Xverify:all','-cp',str(W/'test-support')+os.pathsep+str(PKG/'LegacyForgeBridge-rev313-bootstrap1.jar'),'GateProbe',*map(str,args)])
def flag(name,value):p=probe('set',G/'config/legacyforgebridge-modules.properties','enabled.'+name,str(value).lower());assert p.returncode==0,p.stdout
def prop(path,key):return probe('get',G/path,key).stdout
nrun=0
def boot(name,ok=True,has=None):
 global nrun;nrun+=1;t=time.monotonic();p=execute(['java','-Xmx2g','-Xverify:all','-Djava.awt.headless=true','-jar',str(G/'lfb/LFB-Bootstrap.jar'),str(G)])
 (OUT/f'{nrun:02d}-{name}.log').write_text(p.stdout)
 record(name,(p.returncode==0)==ok and (has is None or has in p.stdout),f'exit={p.returncode}, seconds={time.monotonic()-t:.3f}; expected {has!r}; log {nrun:02d}-{name}.log')
 if not ok:record(name+'-no-launch-ticket',not(G/'lfb/launch-ticket.properties').exists())
 return p

def fixture(name,id='fixture',dep=''):
 p=execute(['java','--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','-cp',str(W/'tools'),'MakeAnnotationFixture',str(G/'old-mods'/name),id,dep]);assert p.returncode==0,p.stdout

def zipreplace(path,name,b):
 with zipfile.ZipFile(path)as z:data={n:z.read(n)for n in z.namelist()}
 data[name]=b
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED)as z:
  for n,v in data.items():z.writestr(n,v)

if ROOT.exists():shutil.rmtree(ROOT)
for d in ['mods','old-mods','lfb','config']:(G/d).mkdir(parents=True,exist_ok=True)
for p in PKG.iterdir():
 if p.suffix=='.jar' or p.name=='bundle.properties':shutil.copyfile(p,(G/'mods' if p.name.startswith('LegacyForgeBridge') else G/'lfb')/p.name)
(G.parent/'mmc-pack.json').write_text(json.dumps({'components':[{'uid':'net.minecraft','version':'1.21.11'},{'uid':'net.fabricmc.fabric-loader','version':'0.19.3'}]}))
for rel,src in [('com/google/code/gson/gson/2.8.9/gson-2.8.9.jar','test-gson-texplate.jar'),('org/ow2/asm/asm/9.test/asm-9.test.jar','test-asm-jdk21.jar'),('com/google/guava/guava/test-local/guava-test-local.jar','test-guava-kotlin.jar')]:
 t=ROOT/'libraries'/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/'lib'/src,t)
normal=G/'mods/normal-fixture.jar'
with zipfile.ZipFile(normal,'w')as z:z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':'normal_fixture','version':'1.0.0'}))
nh=sha(normal);fixture('Fixture.jar');src=G/'old-mods/Fixture.jar';source_hash=sha(src)
p=boot('cold-full-conversion',has='PREPARE_OK converted=1 reused=0 enabled=1');candidate=G/'lfb/cache/converted/Fixture-lfb.jar';live=G/'mods/Fixture-lfb.jar'
record('all-118-original-passes-and-three-extras',p.stdout.count('PASS_RESULT ')==121)
with zipfile.ZipFile(live)as z:
 d=json.loads(z.read('fabric.mod.json'));record('fabric-candidate-produced',d['id']=='fixture' and 'legacyforgebridge/generated-entrypoint.marker'in z.namelist())
 record('original-Forge-class-stripped',all(not n.startswith('fixture/')for n in z.namelist()))
record('source-read-only',sha(src)==source_hash);record('normal-mod-read-only',sha(normal)==nh);initial=sha(live)
p=boot('warm-cache-hit',has='PREPARE_OK converted=0 reused=1 enabled=1');record('no-passes-on-cache-hit','PASS_RESULT 'not in p.stdout and sha(live)==initial)
record('gate-valid-ticket',probe('gate',G,RUNTIME).returncode==0)
record('gate-refuses-consumed-ticket',probe('gate',G,RUNTIME).returncode!=0)
boot('prepare-for-game-lock',has='CACHE_HIT')
held=subprocess.Popen(['java','-cp',str(W/'test-support')+os.pathsep+str(PKG/'LegacyForgeBridge-rev313-bootstrap1.jar'),'GateProbe','gate',str(G),str(RUNTIME),'6000'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=ENV)
while True:
 line=held.stdout.readline()
 if 'GATE_OK'in line:break
 if not line:raise AssertionError('Lock process failed')
ticket_hash=sha(G/'lfb/launch-ticket.properties')
p=execute(['java','-Djava.awt.headless=true','-jar',str(G/'lfb/LFB-Bootstrap.jar'),str(G)])
record('running-game-lock-blocks-bootstrap',p.returncode!=0 and 'close this instance'in p.stdout)
record('lock-failure-does-not-delete-ticket',(G/'lfb/launch-ticket.properties').exists() and sha(G/'lfb/launch-ticket.properties')==ticket_hash)
held.terminate();held.wait(timeout=6)
flag('Fixture.jar',False);boot('disable',has='enabled=0');record('disable-removes-live-output-only',not live.exists() and src.exists() and candidate.exists() and sha(src)==source_hash)
flag('Fixture.jar',True);boot('reenable-cache',has='converted=0 reused=1');record('reenable-same-artifact',sha(live)==initial)
zipreplace(src,'assets/fixture/lang/en_US.lang',b'fixture.label=Changed value\n');boot('source-update-reconverts',has='converted=1 reused=0');record('update-output-changed',sha(live)!=initial)
changed=sha(live);good_candidate=candidate.read_bytes();candidate.write_bytes(b'corrupt cache');boot('corrupt-cache-reconverts',has='CONVERT_START');record('candidate-rebuilt',zipfile.is_zipfile(candidate) and zipfile.is_zipfile(live))
live.unlink();boot('missing-managed-output-restaged',has='converted=0 reused=1');record('live-output-restored',live.exists())
# The runtime gate must reject disk changes after preparation.
orig=live.read_bytes();live.write_bytes(b'corrupt live');record('gate-rejects-modified-output',probe('gate',G,RUNTIME).returncode!=0);live.write_bytes(orig)
flag('Fixture.jar',False);record('gate-rejects-changed-enable-setting',probe('gate',G,RUNTIME).returncode!=0);flag('Fixture.jar',True)
# Invalid source ZIP must stop before any managed output is changed.
good=src.read_bytes();before=sha(live);src.write_bytes(b'not a ZIP');boot('invalid-source-stops',False,has='PREPARE_FAILED');record('failure-preserves-current-output',sha(live)==before);src.write_bytes(good)
flag('Fixture.jar','not-a-boolean');boot('invalid-preference-stops',False,has='Invalid enable flag');flag('Fixture.jar',True)
fixture('Needs.jar','needs','required-after:absent');boot('missing-required-source-stops',False,has='requires an enabled source mod absent');(G/'old-mods/Needs.jar').unlink()
fixture('Duplicate.jar','fixture');boot('duplicate-legacy-id-stops',False,has='Duplicate legacy mod ID');(G/'old-mods/Duplicate.jar').unlink()
fixture('Needs.jar','needs','required-after:fixture');flag('Fixture.jar',False);boot('disabled-required-source-stops',False,has='requires an enabled source mod fixture');(G/'old-mods/Needs.jar').unlink();flag('Fixture.jar',True)
# Fabric ID owned by a normal mod: do not overwrite or hide it.
conflict=G/'mods/normal-conflict.jar'
with zipfile.ZipFile(conflict,'w')as z:z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':'fixture','version':'1.0.0'}))
h=sha(conflict);boot('normal-fabric-id-conflict-stops',False,has='already owns converted ID');record('conflicting-normal-mod-preserved',sha(conflict)==h);conflict.unlink()
# A valid normal file at desired candidate path must not be overwritten.
backup=live.read_bytes()
with zipfile.ZipFile(live,'w')as z:z.writestr('fabric.mod.json',json.dumps({'schemaVersion':1,'id':'unrelated_collision','version':'1.0.0'}))
h=sha(live);boot('filename-collision-stops',False,has='Will not overwrite');record('filename-collision-file-preserved',sha(live)==h);live.write_bytes(backup)
# Recover a genuine partially-applied deployment from its journal.
boot('prepare-for-recovery',has='CACHE_HIT');d=G/'lfb/transactions/test-recovery';d.mkdir(parents=True);(d/'0.previous').write_bytes(live.read_bytes());old=sha(live);live.write_bytes(b'staged corrupted output');new=sha(live)
args=['set',G/'lfb/transaction.properties','count','1','directory','lfb/transactions/test-recovery','op.0.target','mods/Fixture-lfb.jar','op.0.existed','true','op.0.backup','lfb/transactions/test-recovery/0.previous','op.0.oldSha',old,'op.0.newSha',new]
assert probe(*args).returncode==0
boot('recover-interrupted-deployment',has='Previous interrupted deployment rolled back safely');record('recovery-restores-valid-artifact',sha(live)==old and not(G/'lfb/transaction.properties').exists())
# Removal retires output without accidentally touching an unrelated normal mod.
saved=src.read_bytes();src.unlink();boot('source-removed',has='enabled=0');record('source-removal-retires-output',not live.exists() and sha(normal)==nh)
# Unicode and spaces in both directory AND source file name.
fixture('測試 模組.jar','unicode_fixture');boot('unicode-source-name',has='converted=1 reused=0');record('unicode-candidate-created',(G/'mods/測試 模組-lfb.jar').exists());record('unicode-gate',probe('gate',G,RUNTIME).returncode==0)
# Package mismatch and missing external dependencies are fail-closed.
runtime_bytes=RUNTIME.read_bytes();RUNTIME.write_bytes(runtime_bytes+b'tampered');boot('runtime-package-mismatch-stops',False,has='does not match');RUNTIME.write_bytes(runtime_bytes)
boot('valid-again',has='CACHE_HIT')
libs=ROOT/'libraries';libs.rename(ROOT/'libraries.off')
boot('missing-library-folder-stops',False,has='Cannot find Prism libraries');(ROOT/'libraries.off').rename(libs)
record('path-traversal-rejected',probe('scoped',G,'../outside.jar').returncode!=0)
# Altered origin after preparation: refuse to start, even if cache exists.
boot('prepare-inventory-check',has='CACHE_HIT');u=G/'old-mods/測試 模組.jar';ub=u.read_bytes();zipreplace(u,'new.txt',b'changed');record('gate-rejects-modified-original',probe('gate',G,RUNTIME).returncode!=0);u.write_bytes(ub)
record('original-main-test-payload-unchanged',sha(PKG/'LegacyForgeBridge-rev313-bootstrap1.jar')==sha(RUNTIME))
print('TOTAL',len(results),'PASS',sum(r['passed']for r in results))
