from pathlib import Path
import os,subprocess,shutil,json,hashlib
W=Path(__file__).resolve().parents[1];pkg=W/'build/LFB_Package';root=W/'regression/tests/Regression Program Files 中文';g=root/'instances/Layout migration/minecraft';env={**os.environ,'LANG':'C.UTF-8','LC_ALL':'C.UTF-8'}
if g.exists():shutil.rmtree(g)
for d in ['mods','lfb','old-mods']:(g/d).mkdir(parents=True,exist_ok=True)
for f in pkg.iterdir():
 if f.suffix=='.jar' or f.name=='bundle.properties':shutil.copyfile(f,g/('mods' if f.name.startswith('LegacyForgeBridge') else 'lfb')/f.name)
(g.parent/'mmc-pack.json').write_text(json.dumps({'components':[{'uid':'net.minecraft','version':'1.21.11'},{'uid':'net.fabricmc.fabric-loader','version':'0.19.3'}]}))
p=subprocess.run(['java','--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','-cp',str(W/'regression/tools'),'MakeAnnotationFixture',str(g/'old-mods/LayoutFixture.jar'),'layoutfixture',''],capture_output=True,text=True,env=env);assert p.returncode==0,p.stdout+p.stderr
cmd=['java','-Xmx2g','-Xverify:all','-Djava.awt.headless=true','-jar',str(g/'lfb/LFB-Bootstrap.jar'),str(g)]
p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=40);assert p.returncode==0,p.stdout+p.stderr
cache=g/'lfb/cache';jar=cache/'converted/LayoutFixture-lfb.jar';digest=hashlib.sha256(jar.read_bytes()).hexdigest()
# Simulate identical valid content recorded under the old folder layout.
cache.rename(g/'legacy-cache');(g/'lfb/layout.properties').unlink()
pth=g/'legacy-cache/conversion-state.json'
if pth.exists():pth.write_text(pth.read_text().replace('"lfb/cache/','"legacy-cache/'))
p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=40);(W/'verification/warm-layout-integration.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stdout+p.stderr
assert 'PREPARE_OK converted=0 reused=1 enabled=1' in p.stdout,p.stdout
assert 'PASS_RESULT ' not in p.stdout and not (g/'legacy-cache').exists()
assert hashlib.sha256(jar.read_bytes()).hexdigest()==digest
assert (g/'lfb/logs/bootstrap.log').exists() and (g/'lfb/logs/layout-migration.log').exists()
(W/'verification/warm-layout-integration.json').write_text(json.dumps({'passed':True,'scope':'real packaged Bootstrap/worker synthetic-source conversion, then old-to-new directory migration','reused':1,'convertedAfterLayoutOnlyMigration':0,'candidateSha256Preserved':digest,'gameExecuted':False},indent=2))
print('PASS real bootstrap migration: preserved candidate SHA; converted=0 reused=1, no second conversion caused by layout alone')
