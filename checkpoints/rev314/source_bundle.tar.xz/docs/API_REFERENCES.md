# 原始 API 核對（2026-10-10）
Minecraft 1.21.11，Yarn 1.21.11+build.4：
- https://maven.fabricmc.net/docs/yarn-1.21.11+build.4/net/minecraft/client/model/ModelPart.Cuboid.html
  class_630$class_628；public final sides / field_3649；IIFFFFFFFFFZFFLjava/util/Set; constructor。
- https://maven.fabricmc.net/docs/yarn-1.21.11+build.4/net/minecraft/client/model/ModelPart.Quad.html
  class_630$class_593；public record canonical constructor (Vertex[], Vector3fc)。
- https://maven.fabricmc.net/docs/yarn-1.21.11+build.4/net/minecraft/client/model/ModelPart.Vertex.html
  class_630$class_618；public record canonical constructor (float,float,float,float,float)。

上列是簽章核對，不是實際 Minecraft 連結或渲染驗證。
