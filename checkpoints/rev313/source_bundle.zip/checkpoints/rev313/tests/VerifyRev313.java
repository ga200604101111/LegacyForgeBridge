import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;

/** Actual bytecode basic-stack verifier. Does not emulate Minecraft's real class loader. */
public final class VerifyRev313 {
    public static void main(String[] args) throws Exception {
        Path compiled=Path.of(args[0]);int classes=0,methods=0;
        try(var list=Files.walk(compiled)){
          for(var file:list.filter(p->p.toString().endsWith(".class")).toList()){
            ClassNode cls=new ClassNode();new ClassReader(Files.readAllBytes(file)).accept(cls,0);
            for(MethodNode method:cls.methods){
              if((method.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))!=0)continue;
              new Analyzer<>(new BasicVerifier()).analyze(cls.name,method);
              methods++;
            }
            classes++;
          }
        }
        try (JarFile base=new JarFile(args[1])) {
           for(String required:List.of(
               "dev/yinghuang/legacyforgebridge/rev311/Rev311CritterBlock.class",
               "dev/yinghuang/legacyforgebridge/rev311/Rev311CritterBlockEntity.class",
               "dev/yinghuang/legacyforgebridge/rev311/Rev311CritterRenderer.class",
               "dev/yinghuang/legacyforgebridge/rev311/Rev311CritterClientRuntime.class")) {
             if(base.getJarEntry(required)==null) throw new AssertionError("Missing preserved base class " +required);
           }
        }
        System.out.println("REV313 BASIC BYTECODE PASS classes="+classes+" methods="+methods);
    }
}
