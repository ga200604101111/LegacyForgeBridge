import dev.yinghuang.legacyforgebridge.rev313.Rev313CritterAmbience;
import java.util.*;
public final class Rev313AmbienceTest {
    static long assertions;
    static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);assertions++;}
    public static void main(String[] args){
        for(long seed=0;seed<100;seed++){
            var cicada = new Rev313CritterAmbience(seed);
            var twin=new Rev313CritterAmbience(seed);
            var firefly=new Rev313CritterAmbience(seed);
            int notes=0,fx=0;
            for(int tick=0;tick<6000;tick++){
                var c=cicada.advance(tick,false); var cdup=twin.advance(tick,false); var f=firefly.advance(tick,true);
                check(c.equals(cdup),"same seed/tick: deterministic");
                check(c.notes()>=0&&c.notes()<=1&&c.tinyFireflies()==0,"cicada effects bounds");
                check(f.tinyFireflies()>=0&&f.tinyFireflies()<=1&&f.notes()==0,"firefly effects bounds");
                check(cicada.advance(tick,false).equals(Rev313CritterAmbience.Events.NONE),"no duplicate game tick cicada");
                check(firefly.advance(tick,true).equals(Rev313CritterAmbience.Events.NONE),"no duplicate game tick firefly");
                notes+=c.notes();fx+=f.tinyFireflies();
            }
            check(notes>100 && notes<1600,"cicada notes over singing cycles: "+notes);
            check(fx>120 && fx<650,"firefly particles approximating 1/20 per tick: "+fx);
        }
        var largeGap=new Rev313CritterAmbience(555); var single=new Rev313CritterAmbience(1);
        check(largeGap.advance(0,false).notes()<=1,"first tick");
        check(largeGap.advance(100000,false).notes()<=1,"bounded missed-tick event");
        check(largeGap.advance(100000,false).equals(Rev313CritterAmbience.Events.NONE),"bounded missed-tick no replay");
        check(largeGap.advance(10,false).tinyFireflies()==0,"clock reset no server mutation");
        check(single.advance(1000,true).tinyFireflies()<=1,"firefly first tick");
        System.out.println("REV313 AMBIENCE PASS assertions="+assertions+" seeds=100 tickRange=6000");
    }
}
