# LegacyForgeBridge rev313 — 暮色森林昆蟲模型／動畫補完（客戶端）

本次以 **rev312 完整主 JAR** 為基底，只更新 `rev311` 的昆蟲呈現類別與版本資訊，不重做共用來源分析、不修改 `old-mods` 原始 JAR 或舊版 Forge 伺服器。

## 檔案識別

- base: `legacyforgebridge-0.2.0-alpha.27-rev312-shared-source-analysis.jar`
- base SHA-256: `ad433e14755d73b57da88d8c6f764a210a61cfffbdcecd52893dc1c1629ff99b`
- 完整主 JAR: `legacyforgebridge-0.2.0-alpha.27-rev313-critter-animation-completion.jar`
- main SHA-256: `fe5c654109888720bb9fd51325c6f295d62120854e361b45e35a63eda1f851dc`
- main bytes: 5,277,146
- Version: `0.2.0-alpha.27-corpus4-local.67-rev313-critter-visual-completion.1`
- Converter semantic revision: `2026-10-09.310-pre-atlas-critter-source-flat-icon` **不變**。
- 原始 Twilight Forest 2.3.8-tw SHA-256: `1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589`

## 修補

1. **六部件蟬、三部件＋獨立光暈螢火蟲：** 保留原始 ModelRenderer 64×32 貼圖 UV、方塊附著方向、既有 per-BlockEntity 轉頭／光暈狀態。把不透明身體改用新版有明確 API 對應的 `entityCutoutNoCull`，避免薄翅膀背面被剔除。
2. **螢火蟲發光層：** 原始 10×0×10 的零厚度平面，在新版 `ModelPart.Cube` 中改為 10×(1/256)×10 像素極薄雙面面片。繼續使用 fullbright 與逐刻 0.05 漸變 alpha；現代混色是近似呈現，不是完全相同的舊版 GL 加法混色。
3. **蟬鳴音符：** 每個昆蟲方塊實體自帶獨立進度。按照原始 `TileEntityTFCicada` 100–199 刻延遲、100 刻鳴唱和 1/5 機率產生音符；僅補客戶端視覺粒子。原伺服器的 cicada 音訊權限不在客戶端重放，以免雙重鳴叫。
4. **螢火蟲微光：** 依原版 `TileEntityTFFirefly` 約每刻 1/20 的出現機率產生現代小螢火蟲粒子，並限制一方塊同一刻重覆發射。這不是完整的 `EntityTFTinyFirefly` 生物／網路生命週期。
5. **錯誤可觀測性：** 如果來源吻合的暮色森林已載入但未找到原始昆蟲 BlockEntity 渲染規則，將寫入警告；成功註冊會記錄渲染器數量，避免再次把未載入誤認為已完成。
6. **物品欄維持 2D：** `assets/twilightforest/textures/blocks/TFCicada.png` 和 `TFFirefly.png` 16×16 平面圖示的 rev310 圖集資源與背包模型未修改。

## 安全與驗證界線

- 完整主 JAR ZIP CRC：PASS，無重複條目、無打包 JDK ASM、無編譯用 API stubs。
- 2032 舊條目中僅替換五個 `.class` 與 `fabric.mod.json`，另外新增三個用戶端特效類別。其餘 **2,026 個條目內容逐一位元組相同**。
- Java 21 JDK 真正 ASM 的 BasicVerifier：11 個新／變更類別、54 個方法通過。
- 純 Java 粒子時間邏輯：100 個種子 × 6,000 刻，加上重複時刻、時鐘重設與延遲上限共 **3,000,205 項檢查**。
- 原始模組 JAR 靜態檢查：六個蟬 cuboid、四個螢火蟲 cuboid、64×32 模型材質及 16×16 物品圖示匹配。
- 二次封裝 JAR SHA-256 完全相同。
- **沒有實際執行 Minecraft 1.21.11、Fabric Loader、原始 1.7.10 伺服器、完整來源轉換、實際 ModelPart 影格或真人遊戲視覺測試。** 編譯使用了簽名相容、獨立保留的暫時性 API stubs，不能假稱實際 Fabric API 相容已驗證。

## 重建

需 Java 21、Python 3.11+、**恰好指定 SHA 的 rev312 JAR**。在此檢查點資料夾：

```bash
python tools/build_rev313.py --base /path/to/rev312.jar --out /path/to/rev313.jar
```

此工具會建立本機暫存編譯用 API stubs，僅用於簽名檢查，不打包進 JAR；使用主機 JDK 隨附 ASM 進行離線方法資料流檢查。原始模組、字體及第三方二進位依賴不包含在檢查點。

## 安裝測試

Fabric 1.21.11 `mods` **僅保留 rev313 一份**，原始暮色森林維持在 `old-mods`。轉換語意版未改，不需為此刪除可用的候選快取；如果暮色森林候選還沒完成安裝，仍應遵照 LFG 的提示重新啟動。

測試：方塊六面、蟬的眼睛／腳／翅膀和轉頭、螢火蟲發光層強度與每刻動態、兩個 2D 背包圖示、音符與微光粒子。如果有任一項仍失敗，請提供 **實際生成的 `twilightforest*-lfb.jar` + `logs/latest.log`**，再逐條追查是否是候選資源、BER 註冊或 RenderType 問題。

只允許推到 `feature/generic-conversion-iyamato-corpus3`，所有提交訊息附 `[skip ci] [skip actions]`。不得啟動 Actions 或動 `main`。
