package dev.yinghuang.legacyforgebridge.rev311;

import dev.yinghuang.legacyforgebridge.convert.runtime.ConvertedLegacyBlock;
import net.minecraft.class_2343;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_1937;
import net.minecraft.class_5819;

/** World-only TESR carrier; BlockItem rendering remains source-proven flat 2D. */
public final class Rev311CritterBlock extends ConvertedLegacyBlock implements class_2343 {
    private final class_2960 id;
    public Rev311CritterBlock(class_2960 id,class_4970.class_2251 settings){
        super(id,settings.method_22488());
        this.id=id;
        if(Rev311CritterRegistry.rule(id)==null)throw new IllegalArgumentException("Unknown visual critter id "+id);
    }
    @Override public class_2586 method_10123(class_2338 pos,class_2680 state) {
        return new Rev311CritterBlockEntity(pos,state);
    }
    @Override protected class_2464 method_9604(class_2680 state){return class_2464.field_11455;}
    /** Client-only source visual tick; avoids the old generic ad-hoc particle duplication. */
    @Override public void method_9496(class_2680 state,class_1937 level,class_2338 pos,class_5819 random) {
        dev.yinghuang.legacyforgebridge.rev313.Rev313CritterEffects.animateTick(id,state,level,pos,random);
    }
}
