package dev.yinghuang.legacyforgebridge.rev311;

import net.minecraft.class_5616;
import dev.yinghuang.legacyforgebridge.LegacyForgeBridge;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2591;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Registers source-bound block-entity animation renderers on the Fabric client thread. */
public final class Rev311CritterClientRuntime {
    private static final Set<String> REGISTERED=ConcurrentHashMap.newKeySet();
    private Rev311CritterClientRuntime(){}
    public static void initialize(){
        if(FabricLoader.getInstance().getModContainer("twilightforest").isPresent()
                && Rev311CritterRegistry.rules().isEmpty())
            LegacyForgeBridge.LOGGER.warn("Twilight Forest critter BER rules missing: source SHA, converted-content class IDs, or original model PNG paths did not pass admission. Keep converted -lfb.jar and latest.log for inspection.");
        int added=0;
        for(Rev311CritterRegistry.Rule rule:Rev311CritterRegistry.rules()) {
            if(!REGISTERED.add(rule.id().toString()))continue;
            class_2591<Rev311CritterBlockEntity> type=Rev311CritterRegistry.type(rule.id());
            if(type!=null){class_5616.method_32144(type,ctx->new Rev311CritterRenderer(ctx,rule));added++;}
            else REGISTERED.remove(rule.id().toString());
        }
        if(added>0)LegacyForgeBridge.LOGGER.info("Twilight Forest critter BER registered: {} source-verified world renderers",added);
    }
}
