package dev.yinghuang.legacyforgebridge.rev313;

import java.util.Random;

/**
 * Client-only source-inspired ambient event pacing, owned by ONE block entity.
 * No Forge world/entity/sound code is executed and no world state is changed.
 * The old server remains the owner of the actual recorded cicada sound.
 */
public final class Rev313CritterAmbience {
    public record Events(int notes, int tinyFireflies) {
        public static final Events NONE = new Events(0, 0);
    }
    private final Random random;
    private long lastTick=Long.MIN_VALUE;
    private int singDelay, singDuration;
    private boolean singing;

    public Rev313CritterAmbience(long seed){
        random=new Random(seed ^ 0xC1CADEF17EEL);
    }

    /** Advances at most 200 source-equivalent ticks, emitting bounded visual events. */
    public synchronized Events advance(long gameTime,boolean firefly) {
        if(gameTime<0) return Events.NONE;
        if(lastTick==Long.MIN_VALUE) lastTick=gameTime-1;
        else if(gameTime<lastTick) {
            lastTick=gameTime-1;
            singDelay=0;singDuration=0;singing=false;
        }
        long elapsed=gameTime-lastTick;
        if(elapsed<=0)return Events.NONE;
        lastTick=gameTime;
        int notes=0,tiny=0;
        for(int n=0;n<Math.min(200,elapsed);n++) {
            if(firefly) {
                // Original TileEntityTFFirefly spawns EntityTFTinyFirefly with probability 1/20
                // near players. The client may only show a particle representation, no entity AI.
                if(random.nextInt(20)==0)tiny=1;
            } else {
                if(singDelay>0)singDelay--;
                else {
                    if(singing && singDuration>=100){singing=false;singDuration=0;}
                    if(singing && singDuration<100) {
                        singDuration++;
                        // Original doSingAnimation() emits notes with probability 1/5 per tick.
                        if(random.nextInt(5)==0)notes=1;
                    }
                    if(!singing && singDuration<=0) {
                        singing=true;
                        singDelay=100+random.nextInt(100);
                    }
                }
            }
        }
        return new Events(notes,tiny);
    }
}
