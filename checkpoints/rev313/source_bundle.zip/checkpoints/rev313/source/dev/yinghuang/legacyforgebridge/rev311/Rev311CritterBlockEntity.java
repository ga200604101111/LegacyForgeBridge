package dev.yinghuang.legacyforgebridge.rev311;

import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2338;
import net.minecraft.class_7923;

/** Per-position animation owner. No NBT mutation and no client-side combat/entity simulation. */
public final class Rev311CritterBlockEntity extends class_2586 {
    private final Rev311CritterMotion motion;
    private final dev.yinghuang.legacyforgebridge.rev313.Rev313CritterAmbience ambient;
    public Rev311CritterBlockEntity(class_2338 pos,class_2680 state) {
        super(Rev311CritterRegistry.requireType(class_7923.field_41175.method_10221(state.method_26204())),pos,state);
        long seed=pos.method_10263()*341873128712L + pos.method_10264()*132897987541L +pos.method_10260()*42317861L;
        motion=new Rev311CritterMotion(seed);
        ambient=new dev.yinghuang.legacyforgebridge.rev313.Rev313CritterAmbience(seed);
    }
    public dev.yinghuang.legacyforgebridge.rev313.Rev313CritterAmbience ambient(){return ambient;}
    public void updateVisual(long gameTime,boolean isFirefly){motion.advance(gameTime,isFirefly);}
    public float yaw(float partial){return motion.yaw(partial);}
    public float glow(float partial){return motion.glow(partial);}
}
