package dev.yinghuang.legacyforgebridge.rev313;

import dev.yinghuang.legacyforgebridge.rev311.Rev311CritterBlockEntity;
import dev.yinghuang.legacyforgebridge.rev311.Rev311CritterRegistry;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_1937;
import net.minecraft.class_5819;

/**
 * Visual only. Source cicada song/audio is sent by the original 1.7.10 server and
 * must not be replayed here. Tiny fireflies use modern ambient particles rather than
 * spawning client-owned legacy mobs, and can be fully implemented separately.
 */
public final class Rev313CritterEffects {
    private Rev313CritterEffects(){}
    public static void animateTick(class_2960 id,class_2680 state,class_1937 level,class_2338 pos,class_5819 random){
        if(level==null||!level.method_8608()||id==null||pos==null||random==null)return;
        Rev311CritterRegistry.Rule rule=Rev311CritterRegistry.rule(id);
        if(rule==null)return;
        if(!(level.method_8321(pos) instanceof Rev311CritterBlockEntity entity))return;
        boolean firefly=rule.kind()==Rev311CritterRegistry.Kind.FIREFLY;
        Rev313CritterAmbience.Events events=entity.ambient().advance(level.method_75260(),firefly);
        if(events==Rev313CritterAmbience.Events.NONE || events.notes()==0 && events.tinyFireflies()==0)return;
        double x=pos.method_10263(),y=pos.method_10264(),z=pos.method_10260();
        for(int i=0;i<events.notes();i++)
            level.method_8406(class_2398.field_11224,
                    x+random.method_43057(),y+random.method_43057(),z+random.method_43057(),0D,0D,0D);
        for(int i=0;i<events.tinyFireflies();i++)
            level.method_8406(class_2398.field_56509,
                    x+random.method_43057(),y+random.method_43057(),z+random.method_43057(),0D,0D,0D);
    }
}
