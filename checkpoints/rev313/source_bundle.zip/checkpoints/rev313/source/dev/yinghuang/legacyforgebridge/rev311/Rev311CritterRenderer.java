package dev.yinghuang.legacyforgebridge.rev311;

import net.minecraft.class_827;
import net.minecraft.class_5614;
import net.minecraft.class_11954;
import net.minecraft.class_630;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_11683;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_1921;
import net.minecraft.class_12249;
import net.minecraft.class_4608;
import net.minecraft.class_2350;
import java.util.*;

/** Native ModelPart renderer using the original source ModelRenderer cuboids/UVs.
 * Rendering states (yaw/glow) are kept per BlockEntity, not global and not server mutable.
 */
public final class Rev311CritterRenderer implements class_827<Rev311CritterBlockEntity,Rev311CritterRenderer.State> {
    private record ModelBox(int u,int v,float x,float y,float z,int w,int h,int d){}
    private static final List<ModelBox> BODY = List.of(
            new ModelBox(0,21,-4,7.9F,-5,8,1,9),
            new ModelBox(0,11,-2,6,-4,4,2,6),
            new ModelBox(0,0,-1,7,-5,2,1,8));
    private static final List<ModelBox> CICADA = List.of(
            BODY.get(0),BODY.get(1),BODY.get(2),
            new ModelBox(20,15,1,5,2,2,2,2),
            new ModelBox(20,15,-3,5,2,2,2,2),
            new ModelBox(20,0,-4,5,-7,8,1,8));
    private static final List<ModelBox> FIREFLY = List.of(
            new ModelBox(0,21,-4,7.9F,-5,8,1,10), BODY.get(1),BODY.get(2));
    private static final ModelBox GLOW=new ModelBox(20,0,-5,5.9F,-9,10,0,10);
    private final Rev311CritterRegistry.Rule rule;
    private final List<class_630> parts;
    private final class_630 glow;
    private final class_1921 cutout;
    private final class_1921 translucent;

    public Rev311CritterRenderer(class_5614.class_5615 ctx,Rev311CritterRegistry.Rule rule){
        this.rule=rule;
        List<ModelBox> boxes=rule.kind()==Rev311CritterRegistry.Kind.CICADA?CICADA:FIREFLY;
        List<class_630> made=new ArrayList<>();for(ModelBox box:boxes)made.add(part(box));
        this.parts=List.copyOf(made);
        this.glow=rule.kind()==Rev311CritterRegistry.Kind.FIREFLY?glowSheet(GLOW):null;
        // The source ModelRenderer does not cull its thin wing/eye underside.
        this.cutout=class_12249.method_75994(rule.texture());
        // 1.7 uses GL_SRC_ALPHA/GL_ONE; modern translucent alpha safely expresses the pulse
        // without manipulating the global pipeline or inventing a server-side light value.
        this.translucent=class_12249.method_76002(rule.texture());
    }
    private static class_630 part(ModelBox b){
        class_630.class_628 cube = new class_630.class_628(b.u,b.v,b.x,b.y,b.z,b.w,b.h,b.d,
                0F,0F,0F,false,64F,32F,EnumSet.allOf(class_2350.class));
        return new class_630(List.of(cube),Map.of());
    }
    /** A genuine double-sided sheet: two extremely close faces have nonzero normal-area.
     * The original ModelRenderer used height=0; the modern cube renderer must not discard it
     * as a degenerate volume. The 1/256 pixel separation is below visual pixel resolution.
     */
    private static class_630 glowSheet(ModelBox b) {
        class_630.class_628 cube=new class_630.class_628(b.u,b.v,b.x,b.y,b.z,b.w,1F/256F,b.d,
                0F,0F,0F,false,64F,32F,EnumSet.allOf(class_2350.class));
        return new class_630(List.of(cube),Map.of());
    }
    @Override public State method_74335(){return new State();}
    @Override public void method_74331(Rev311CritterBlockEntity entity,State state,float partial,
                                       class_243 cameraPos,class_11683.class_11792 crumble){
        class_827.super.method_74331(entity,state,partial,cameraPos,crumble);
        long tick=entity.method_10997()==null?0:entity.method_10997().method_75260();
        entity.updateVisual(tick,rule.kind()==Rev311CritterRegistry.Kind.FIREFLY);
        state.attachment=dev.yinghuang.legacyforgebridge.convert.runtime.ConvertedLegacyBlock.legacyMeta(entity.method_11010())&7;
        state.yaw=entity.yaw(partial);
        state.glow=entity.glow(partial);
    }
    @Override public void method_3569(State state,class_4587 pose,class_11659 queue,class_12075 camera){
        pose.method_22903();
        pose.method_46416(0.5F,0.5F,0.5F);
        float x=90F,z=0F;
        switch(state.attachment){
            case 1 -> z=-90F; case 2 -> z=90F; case 4 -> z=180F;
            case 5 -> x=0F; case 6 -> x=180F;
            default -> { }
        }
        pose.method_22907(class_7833.field_40714.rotationDegrees(x));
        pose.method_22907(class_7833.field_40718.rotationDegrees(z));
        pose.method_22907(class_7833.field_40716.rotationDegrees(state.yaw));
        pose.method_22905(1F,-1F,-1F);
        for(class_630 part:parts)queue.method_73492(part,pose,cutout,state.field_62676,class_4608.field_21444,null,0xFFFFFFFF,state.field_62677);
        if(glow!=null&&state.glow>0F){
            int alpha=Math.max(0,Math.min(255,Math.round(state.glow*255F)));
            queue.method_73492(glow,pose,translucent,0xF000F0,class_4608.field_21444,null,(alpha<<24)|0xFFFFFF,state.field_62677);
        }
        pose.method_22909();
    }
    public static final class State extends class_11954{int attachment;float yaw;float glow;}
}
