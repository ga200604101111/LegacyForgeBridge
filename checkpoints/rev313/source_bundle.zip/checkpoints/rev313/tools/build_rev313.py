#!/usr/bin/env python3
"""Rebuild source-backed rev313 from exact rev312 main with Java 21.

The generated external API stub sources are compile-only and NEVER packaged.
Use this as a reproducible offline overlay, not a Fabric integration test.
"""
from pathlib import Path
import argparse,subprocess,sys,os

ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'source'
TESTS=ROOT/'tests'
TOOLS=ROOT/'tools'
WORK=ROOT/'build'

def run(*args):subprocess.run([str(a) for a in args],check=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    run(sys.executable,TOOLS/'create_stubs.py')
    stub_sources=sorted((WORK/'stubs').rglob('*.java'))
    (WORK/'stub-classes').mkdir(parents=True,exist_ok=True)
    run('javac','--release','21','-encoding','UTF-8','-d',WORK/'stub-classes',*stub_sources)
    (WORK/'classes').mkdir(parents=True,exist_ok=True)
    source_files=sorted(JAVA.rglob('*.java'))
    run('javac','--release','21','-encoding','UTF-8','-cp',os.pathsep.join((str(WORK/'stub-classes'),str(a.base))),
        '-d',WORK/'classes',*source_files)
    (WORK/'testclasses').mkdir(parents=True,exist_ok=True)
    for target in ['Rev313AmbienceTest']:
        run('javac','--release','21','-encoding','UTF-8','-cp',WORK/'classes',
            '-d',WORK/'testclasses',TESTS/(target+'.java'))
        run('java','-Xverify:all','-cp',os.pathsep.join((str(WORK/'testclasses'),str(WORK/'classes'))),target)
    run('javac',
        '--add-exports=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED',
        '--add-exports=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED',
        '--add-exports=java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED',
        '-d',WORK/'testclasses',TESTS/'VerifyRev313.java')
    run('java',
        '--add-exports=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED',
        '--add-exports=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED',
        '--add-exports=java.base/jdk.internal.org.objectweb.asm.tree.analysis=ALL-UNNAMED',
        '-cp',WORK/'testclasses','VerifyRev313',WORK/'classes',a.base)
    run(sys.executable,TOOLS/'package_rev313.py','--base',a.base,'--compiled',WORK/'classes','--out',a.out)
