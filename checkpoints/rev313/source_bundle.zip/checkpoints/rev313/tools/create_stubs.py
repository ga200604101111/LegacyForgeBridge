from pathlib import Path
r=Path(__file__).resolve().parents[1] / 'build/stubs'
def s(n,v):
 p=r/n.replace('.','/'); p=p.with_suffix('.java');p.parent.mkdir(parents=True,exist_ok=True);pkg=n.rsplit('.',1)[0];p.write_text('package '+pkg+';\n'+v+'\n')
s('com.google.gson.JsonElement','public class JsonElement {public boolean isJsonObject(){return false;}public boolean isJsonPrimitive(){return false;}public JsonObject getAsJsonObject(){return null;}public String getAsString(){return "";}}')
s('com.google.gson.JsonObject','public class JsonObject extends JsonElement{public JsonElement get(String k){return null;} public boolean has(String k){return false;}public JsonArray getAsJsonArray(String k){return null;}}')
s('com.google.gson.JsonArray','public class JsonArray extends JsonElement implements Iterable<JsonElement>{public java.util.Iterator<JsonElement> iterator(){return java.util.Collections.emptyIterator();}}')
s('com.google.gson.JsonParser','public class JsonParser {public static JsonElement parseReader(java.io.Reader r){return null;}}')
s('net.fabricmc.loader.api.ModContainer','public interface ModContainer{java.util.Optional<java.nio.file.Path> findPath(String path);}')
s('net.fabricmc.loader.api.FabricLoader','public interface FabricLoader{static FabricLoader getInstance(){return null;}java.util.Optional<ModContainer> getModContainer(String id);}')
s('net.minecraft.class_2960','public class class_2960{ public static class_2960 method_60656(String v){return null;} public String toString(){return "";}}')
s('net.minecraft.class_4970','public class class_4970{ public static class class_2251{public class_2251 method_22488(){return this;}}}')
s('net.minecraft.class_2248','public class class_2248 extends class_4970{public class_2248(class_2251 props){} protected net.minecraft.class_2464 method_9604(class_2680 s){return null;}}')
s('net.minecraft.class_2680','public class class_2680{public class_2248 method_26204(){return null;}}')
s('net.minecraft.class_2464','public enum class_2464{field_11455;}')
s('net.minecraft.class_2343','public interface class_2343{class_2586 method_10123(class_2338 pos,class_2680 state);}')
s('net.minecraft.class_2586','public class class_2586 {public class_2586(class_2591 type,class_2338 pos,class_2680 state){}public class_2680 method_11010(){return null;}public class_1937 method_10997(){return null;}}')
s('net.minecraft.class_2591','public class class_2591<T extends class_2586>{}')
s('net.minecraft.class_2338','public class class_2338{public int method_10263(){return 0;}public int method_10264(){return 0;}public int method_10260(){return 0;}}')
s('net.minecraft.class_1937','public class class_1937{public long method_75260(){return 0L;}}')
s('net.minecraft.class_2378','public interface class_2378<T>{boolean method_10250(class_2960 id);static <T> T method_10230(class_2378<T> registry,class_2960 id,T thing){return thing;}}')
s('net.minecraft.class_7922','public interface class_7922<T>{class_2960 method_10221(T item);}')
s('net.minecraft.class_7923','public class class_7923{public static final class_7922<class_2248> field_41175=null;public static final class_2378<class_2591<?>> field_41181=null;}')
s('net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder','public class FabricBlockEntityTypeBuilder<T extends net.minecraft.class_2586>{public interface Factory<T extends net.minecraft.class_2586>{T create(net.minecraft.class_2338 pos,net.minecraft.class_2680 state);} public static <T extends net.minecraft.class_2586> FabricBlockEntityTypeBuilder<T> create(Factory<T> factory,net.minecraft.class_2248... blocks){return null;}public net.minecraft.class_2591<T> build(){return null;}}')
s('net.minecraft.class_5614','public interface class_5614<T extends class_2586>{net.minecraft.class_827<T,?> create(class_5615 context); interface class_5615{}}')
s('net.minecraft.class_5616','public class class_5616{public static <T extends class_2586>void method_32144(class_2591<T> type,class_5614<T> renderer){} }')
s('net.minecraft.class_827','public interface class_827<E extends class_2586,S extends class_11954>{S method_74335(); default void method_74331(E e,S state,float partial,class_243 camera,class_11683.class_11792 crumble){}void method_3569(S state,class_4587 pose,class_11659 queue,class_12075 camera);}')
s('net.minecraft.class_11954','public class class_11954{public int field_62676;public net.minecraft.class_11683.class_11792 field_62677;}')
s('net.minecraft.class_11683','public class class_11683{public static class class_11792{}}')
s('net.minecraft.class_243','public class class_243{}')
s('net.minecraft.class_12075','public class class_12075{}')
s('net.minecraft.class_4587','public class class_4587{public void method_22903(){}public void method_46416(float a,float b,float c){} public void method_22907(org.joml.Quaternionfc q){}public void method_22905(float a,float b,float c){}public void method_22909(){}}')
s('net.minecraft.class_7833','public interface class_7833{class_7833 field_40714=null,field_40716=null,field_40718=null;org.joml.Quaternionf rotationDegrees(float degrees);}')
s('org.joml.Quaternionfc','public interface Quaternionfc{}')
s('org.joml.Quaternionf','public class Quaternionf implements Quaternionfc{}')
s('net.minecraft.class_2350','public enum class_2350{NORTH,SOUTH,EAST,WEST,UP,DOWN;}')
s('net.minecraft.class_630','public class class_630{public static class class_628 {public class_628(int u,int v,float x,float y,float z,float w,float h,float d,float dx,float dy,float dz,boolean mirror,float tw,float th,java.util.Set<class_2350> faces){}}public class_630(java.util.List<class_628> cubes,java.util.Map<String,class_630> children){}}')
s('net.minecraft.class_1921','public class class_1921{}')
s('net.minecraft.class_12249','public class class_12249{public static class_1921 method_75990(class_2960 texture){return null;}public static class_1921 method_76002(class_2960 texture){return null;}}')
s('net.minecraft.class_4608','public class class_4608{public static int field_21444;}')
s('net.minecraft.class_1058','public class class_1058{}')
s('net.minecraft.class_11659','public interface class_11659{void method_73492(class_630 part,class_4587 pose,class_1921 type,int light,int overlay,class_1058 sprite,int color,class_11683.class_11792 crumble);}')
print('stubs',len(list(r.rglob('*.java'))))
# Additional 1.21.11 methods/fields used only by the rev313 visual completion.
s('net.minecraft.class_1937','''public class class_1937 {
 public long method_75260(){return 0L;}
 public boolean method_8608(){return true;}
 public class_2586 method_8321(class_2338 pos){return null;}
 public void method_8406(class_2394 particle,double x,double y,double z,double vx,double vy,double vz){}
}''')
s('net.minecraft.class_12249','''public class class_12249 {
 public static class_1921 method_75990(class_2960 texture){return null;}
 public static class_1921 method_75994(class_2960 texture){return null;}
 public static class_1921 method_76002(class_2960 texture){return null;}
}''')
s('net.minecraft.class_2394','public interface class_2394 {}')
s('net.minecraft.class_2398','public class class_2398 {public static class_2394 field_11224,field_56509;}')
s('net.minecraft.class_5819','public interface class_5819{int method_43048(int limit);float method_43057();}')
