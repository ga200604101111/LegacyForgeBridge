#!/usr/bin/env python3
"""Rebuild complete rev313 main as a narrowly bounded overlay on the exact rev312 JAR.

Do not change original 1.7.10 mod JARs. The base must be the exact rev312
main containing rev311 critter BER and the shared source-analysis layer.
"""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

BASE_SHA = "ad433e14755d73b57da88d8c6f764a210a61cfffbdcecd52893dc1c1629ff99b"
VERSION = "0.2.0-alpha.27-corpus4-local.67-rev313-critter-visual-completion.1"
PREFIX = "dev/yinghuang/legacyforgebridge/"
REPLACE = {
  PREFIX+"BuildInfo.class",
  PREFIX+"rev311/Rev311CritterBlock.class",
  PREFIX+"rev311/Rev311CritterBlockEntity.class",
  PREFIX+"rev311/Rev311CritterClientRuntime.class",
  PREFIX+"rev311/Rev311CritterRenderer.class",
  "fabric.mod.json"
}
ADD = {
  PREFIX+"rev313/Rev313CritterAmbience.class",
  PREFIX+"rev313/Rev313CritterAmbience$Events.class",
  PREFIX+"rev313/Rev313CritterEffects.class"
}

def sha(path):
    with path.open("rb") as f: return hashlib.file_digest(f, "sha256").hexdigest()

def run(base, compiled, target):
    if sha(base)!=BASE_SHA: raise ValueError("Wrong rev312 main baseline; refusing overlay")
    target.parent.mkdir(parents=True,exist_ok=True)
    changes={name:(compiled/name).read_bytes() for name in REPLACE-{"fabric.mod.json"}|ADD}
    with zipfile.ZipFile(base) as previous:
        current=previous.namelist()
        if len(current)!=len(set(current)): raise ValueError("Duplicate base entries")
        if not REPLACE-{"fabric.mod.json"} <= set(current):raise ValueError("Missing target classes in base")
        if ADD & set(current):raise ValueError("Rev313 classes already in source")
        json_meta=json.loads(previous.read("fabric.mod.json"))
        if "rev312" not in json_meta["version"]:raise ValueError("Not rev312 metadata")
        json_meta["version"]=VERSION
        json_meta["description"]=("rev313 source-bound Twilight Forest critter BER: no-cull 6/4 original cuboid UV, "
            "non-degenerate double-sided glow and paced source-like ambient client effects; original server "
            "sounds remain authoritative. Preserves rev312 shared analysis, rev310 2D inventory models and existing caches. "
            "Offline bytecode/fixture tests only; no live Minecraft validation.")
        changes["fabric.mod.json"]=(json.dumps(json_meta,indent=2,ensure_ascii=False)+"\n").encode()
        with zipfile.ZipFile(target,'w') as output:
            for info in previous.infolist():
                data=changes.get(info.filename)
                output.writestr(info,data if data is not None else previous.read(info.filename))
            for name in sorted(ADD):
                info=zipfile.ZipInfo(name, (1980,1,1,0,0,0))
                info.compress_type=zipfile.ZIP_DEFLATED
                output.writestr(info,changes[name])
    with zipfile.ZipFile(base) as previous,zipfile.ZipFile(target) as new:
        assert new.testzip() is None
        assert len(new.namelist())==len(set(new.namelist()))
        assert len(new.namelist())==len(previous.namelist())+len(ADD)
        protected=[n for n in previous.namelist() if n not in REPLACE]
        for n in protected:
            if previous.read(n)!=new.read(n):raise AssertionError("Unrelated entry changed: "+n)
        assert VERSION.encode() in new.read(PREFIX+"BuildInfo.class")
        assert json.loads(new.read("fabric.mod.json"))["version"]==VERSION
        assert not any(n.startswith("org/objectweb/asm/") or n.startswith("jdk/")
                       or n.startswith("META-INF/jars/asm") or n.startswith("test/") for n in new.namelist())
    return {"sha256":sha(target),"bytes":target.stat().st_size,
            "baseSha256":BASE_SHA,"changedExistingEntries":len(REPLACE),"newClasses":len(ADD),
            "preservedUnchangedEntries":len(protected),"zipIntegrity":True,"version":VERSION,
            "converterRevisionUnchanged":True,"liveMinecraftTested":False}

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--base",type=Path,required=True)
    parser.add_argument("--compiled",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(run(args.base,args.compiled,args.out),indent=2))
