# LegacyForgeBridge rev309 checkpoint

This checkpoint contains complete rev309 source and deterministic resources to be overlaid on exact rev308 JAR.

- Base SHA-256: `40fd1ae599c1a0ca07346ebd4336df3584f9385dc284e14e9d59d55ab7722dbd`
- Full main SHA-256: `6d78a7fbdd9efd64b49fc1200b218ad3cb5cb89c3af5f7dd6e6dcc97bcb29f81`
- Main: `legacyforgebridge-0.2.0-alpha.27-rev309-critter-model-fx-tooltips.jar`
- Minecraft 1.21.11, original 1.7.10 JAR and server unchanged.
- Converter semantic revision bumped to invalidate cached converted content for new model assets.
- SHA bound to exact original Twilight Forest JAR: `1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589`.
- GitHub branch: `feature/generic-conversion-iyamato-corpus3`. Do not trigger Actions or modify main.
- Code and source reconstruction under `src/` and `tools/`; render templates under `resources/`.
- Current overlay uses remapped/intermediary classes with temporary signature-compatible stubs, not standard full Loom build. Stubs are NOT included in user JAR.
- Contents: 14 block model definitions, attached insects, no collision, tiny selection shape, cutout transparency, firefly light15, cicada note & firefly particles; all LFB-added item tooltips moved after item name.
- Archive checked: ZIP CRC valid, no duplicate entries, no bundled ASM, 1,986 untouched baseline entries payload byte-identical.
- NO real Minecraft, ViaFabricPlus or Forge server runtime tests. No gameplay/AI/server hooks modified.
- Install only one main LFB JAR; original Twilight remains in `old-mods`. Rebuild converted candidates and restart Minecraft when LFB reports restart required.
