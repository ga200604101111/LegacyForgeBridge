#!/usr/bin/env python3
"""Complete rev309 LFG overlay on exact rev308, preserving every unmodified ZIP entry payload."""
from pathlib import Path
import hashlib,json,zipfile
base=Path('/mnt/data/legacyforgebridge-0.2.0-alpha.27-rev308-twilight-sword-arrow-equipment.jar')
expected_sha='40fd1ae599c1a0ca07346ebd4336df3584f9385dc284e14e9d59d55ab7722dbd'
output=Path('/mnt/data/legacyforgebridge-0.2.0-alpha.27-rev309-critter-model-fx-tooltips.jar')
root=Path('/mnt/data/lfb309work')
version='0.2.0-alpha.27-corpus4-local.62-rev309-critter-model-fx-tooltips.1'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(base)==expected_sha, 'wrong rev308 baseline'
updates={}
for folder in [root/'inject-classes',root/'classes',root/'resources']:
 for p in folder.rglob('*'):
  if p.is_file():
   key=p.relative_to(folder).as_posix()
   if key in updates:raise AssertionError('duplicate overlay path '+key)
   updates[key]=p.read_bytes()
with zipfile.ZipFile(base) as old:
 names=old.namelist();assert len(names)==len(set(names))
 metadata=json.loads(old.read('fabric.mod.json'))
 metadata['version']=version
 metadata['description']='rev309: restore source-proven Twilight cicada/firefly attached TESR cuboid models, transparent selection/collision, firefly light, client particle visuals, and relocate all LFB-added tooltips to first row after item title. rev308 & rev307 preserved; source SHA bound; cache will regenerate converted candidates.'
 updates['fabric.mod.json']=(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n').encode()
 protected={
 'dev/yinghuang/legacyforgebridge/BuildInfo.class',
 'dev/yinghuang/legacyforgebridge/convert/LegacyJarWriter.class',
 'dev/yinghuang/legacyforgebridge/convert/runtime/GeneratedModSupport.class',
 'dev/yinghuang/legacyforgebridge/convert/runtime/ConvertedLegacyBlock.class',
 'dev/yinghuang/legacyforgebridge/behavior/LegacyBehaviorClient.class',
 'fabric.mod.json'
 }
 overlaps={x for x in updates if x in names};assert overlaps==protected,overlaps^protected
 with zipfile.ZipFile(output,'w') as out:
  for entry in old.infolist():
   out.writestr(entry, updates[entry.filename] if entry.filename in protected else old.read(entry.filename))
  for p in sorted(updates.keys()-set(names)):
   info=zipfile.ZipInfo(p,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   out.writestr(info,updates[p])
with zipfile.ZipFile(base) as old,zipfile.ZipFile(output) as final:
 assert final.testzip() is None
 assert len(final.namelist())==len(set(final.namelist()))
 unchanged=[n for n in old.namelist() if n not in protected]
 for name in unchanged:assert final.read(name)==old.read(name),name
 assert len([x for x in final.namelist() if x.startswith('legacyforgebridge/rev309/templates/') and x.endswith('.json')])==14
 assert len([x for x in final.namelist() if x.startswith('dev/yinghuang/legacyforgebridge/rev309/') and x.endswith('.class')])==4
 assert version.encode() in final.read('dev/yinghuang/legacyforgebridge/BuildInfo.class')
 assert not any(x.startswith('org/objectweb/asm/') or x.startswith('jdk/internal/org/objectweb') for x in final.namelist())
 print('BASE_SHA256',expected_sha)
 print('REV309_SHA256',sha(output))
 print('REV309_BYTES',output.stat().st_size)
 print('REPLACED',len(protected),'ADDED',len(final.namelist())-len(old.namelist()))
 print('UNCHANGED_PAYLOADS',len(unchanged))
 print('ZIP_VALID',True,'NO_DUPLICATES',True,'NO_SHADED_ASM',True)
 print('ARTIFACT',str(output))
