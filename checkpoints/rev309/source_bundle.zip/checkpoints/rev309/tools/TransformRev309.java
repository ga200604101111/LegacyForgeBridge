import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import java.nio.file.*;
import java.util.*;

/** Rev309: exact class/method/classfile preconditions, no broad or name-based bytecode rewrites. */
public final class TransformRev309 implements Opcodes {
    private static final String LIB="dev/yinghuang/legacyforgebridge/rev309/";
    private static final String MC="Lnet/minecraft/";
    private static int sites;
    interface Edit {void accept(ClassNode node);}
    static MethodNode method(ClassNode n,String name,String descriptor){
        return n.methods.stream().filter(m->m.name.equals(name)&&m.desc.equals(descriptor)).findFirst().orElseThrow(()->new IllegalArgumentException("Missing "+n.name+"."+name+descriptor));
    }
    static void patch(Path source,Path result,String internal, Edit edit)throws Exception{
        ClassReader input=new ClassReader(Files.readAllBytes(source.resolve(internal+".class")));
        ClassNode node=new ClassNode();input.accept(node,0);edit.accept(node);
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);node.accept(writer);
        Path target=result.resolve(internal+".class");Files.createDirectories(target.getParent());Files.write(target,writer.toByteArray());
    }
    public static void main(String[]args)throws Exception{
        if(args.length!=2)throw new IllegalArgumentException("usage: TransformRev309 input/output");
        Path source=Path.of(args[0]),target=Path.of(args[1]);
        patch(source,target,"dev/yinghuang/legacyforgebridge/convert/LegacyJarWriter",TransformRev309::jarWriter);
        patch(source,target,"dev/yinghuang/legacyforgebridge/convert/runtime/GeneratedModSupport",TransformRev309::generated);
        patch(source,target,"dev/yinghuang/legacyforgebridge/convert/runtime/ConvertedLegacyBlock",TransformRev309::convertedBlock);
        patch(source,target,"dev/yinghuang/legacyforgebridge/behavior/LegacyBehaviorClient",TransformRev309::tooltip);
        if(sites!=8)throw new AssertionError("Rev309 patch sites "+sites+", expected 8 category anchors");
        System.out.println("rev309 bytecode hooks="+sites+" classes=4");
    }
    static void jarWriter(ClassNode c){
        MethodNode m=method(c,"writeDeterministic","(Ljava/nio/file/Path;Ljava/nio/file/Path;)V");
        InsnList insert=new InsnList();
        insert.add(new VarInsnNode(ALOAD,0));
        insert.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309CritterModelBake","apply","(Ljava/nio/file/Path;)V",false));
        m.instructions.insert(insert);sites++;
    }
    static void generated(ClassNode c){
        MethodNode m=method(c,"registerBlock","(Ljava/lang/String;Ljava/lang/String;)V");
        int count=0;
        for(AbstractInsnNode a=m.instructions.getFirst();a!=null;a=a.getNext()){
            if(a instanceof MethodInsnNode call&&call.owner.equals("dev/yinghuang/legacyforgebridge/compat/LegacyBlockGeometryRegistry")&&call.name.equals("properties")){
                InsnList insert=new InsnList();
                insert.add(new VarInsnNode(ALOAD,2));insert.add(new InsnNode(SWAP));
                insert.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309CritterClient","properties",
                    "(Lnet/minecraft/class_2960;Lnet/minecraft/class_4970$class_2251;)Lnet/minecraft/class_4970$class_2251;",false));
                m.instructions.insert(a,insert);count++;
            }
        }
        if(count!=1)throw new IllegalStateException("Block properties anchor count "+count);
        sites++;
        int layers=0;
        for(AbstractInsnNode instruction=m.instructions.getFirst();instruction!=null;instruction=instruction.getNext()){
            if(!(instruction instanceof MethodInsnNode call) || !call.name.equals("method_39197")
                    || !call.owner.equals("net/minecraft/class_2378"))continue;
            InsnList register=new InsnList();register.add(new VarInsnNode(ALOAD,2));
            register.add(new VarInsnNode(ALOAD,17));register.add(new TypeInsnNode(CHECKCAST,"net/minecraft/class_2248"));
            register.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309CritterClient","renderLayer",
                "(Lnet/minecraft/class_2960;Lnet/minecraft/class_2248;)V",false));
            m.instructions.insert(instruction,register);layers++;break;
        }
        if(layers!=1)throw new IllegalStateException("BlockRegistry/cutout anchor missing");sites++;
    }
    static void convertedBlock(ClassNode c){
        MethodNode animate=method(c,"method_9496","(Lnet/minecraft/class_2680;Lnet/minecraft/class_1937;Lnet/minecraft/class_2338;Lnet/minecraft/class_5819;)V");
        int count=0;
        for(AbstractInsnNode a=animate.instructions.getFirst();a!=null;a=a.getNext()) if(a.getOpcode()==RETURN){
            InsnList x=new InsnList(); x.add(new VarInsnNode(ALOAD,0));
            x.add(new FieldInsnNode(GETFIELD,c.name,"convertedId","Lnet/minecraft/class_2960;"));
            for(int i=1;i<=4;i++)x.add(new VarInsnNode(ALOAD,i));
            x.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309CritterClient","tick",
                "(Lnet/minecraft/class_2960;Lnet/minecraft/class_2680;Lnet/minecraft/class_1937;Lnet/minecraft/class_2338;Lnet/minecraft/class_5819;)V",false));
            animate.instructions.insertBefore(a,x);count++;
        }
        if(count!=1)throw new IllegalStateException("animateTick RETURNS="+count);sites++;
        MethodNode selection=method(c,"method_9530","(Lnet/minecraft/class_2680;Lnet/minecraft/class_1922;Lnet/minecraft/class_2338;Lnet/minecraft/class_3726;)Lnet/minecraft/class_265;");
        int sel=0;
        for(AbstractInsnNode a=selection.instructions.getFirst();a!=null;a=a.getNext()) if(a.getOpcode()==ARETURN){
            InsnList x=new InsnList();x.add(new VarInsnNode(ALOAD,0));
            x.add(new FieldInsnNode(GETFIELD,c.name,"convertedId","Lnet/minecraft/class_2960;"));
            x.add(new VarInsnNode(ALOAD,1));
            x.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309CritterClient","selection",
                 "(Lnet/minecraft/class_265;Lnet/minecraft/class_2960;Lnet/minecraft/class_2680;)Lnet/minecraft/class_265;",false));
            selection.instructions.insertBefore(a,x);sel++;
        }
        if(sel<2||sel>6)throw new IllegalStateException("selection RETURNS="+sel);sites++;
        MethodNode collision=method(c,"method_9549","(Lnet/minecraft/class_2680;Lnet/minecraft/class_1922;Lnet/minecraft/class_2338;Lnet/minecraft/class_3726;)Lnet/minecraft/class_265;");
        int col=0;
        for(AbstractInsnNode a=collision.instructions.getFirst();a!=null;a=a.getNext()) if(a.getOpcode()==ARETURN){
            InsnList x=new InsnList();x.add(new VarInsnNode(ALOAD,0));
            x.add(new FieldInsnNode(GETFIELD,c.name,"convertedId","Lnet/minecraft/class_2960;"));
            x.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309CritterClient","collision",
                   "(Lnet/minecraft/class_265;Lnet/minecraft/class_2960;)Lnet/minecraft/class_265;",false));
            collision.instructions.insertBefore(a,x);col++;
        }
        if(col<2||col>6)throw new IllegalStateException("collision RETURNS="+col);sites++;
    }
    static void tooltip(ClassNode c){
        MethodNode m=method(c,"lambda$onInitializeClient$2",
                "(Lnet/minecraft/class_1799;Lnet/minecraft/class_1792$class_9635;Lnet/minecraft/class_1836;Ljava/util/List;)V");
        InsnList begin=new InsnList();begin.add(new VarInsnNode(ALOAD,3));
        begin.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309TooltipOrder","begin","(Ljava/util/List;)V",false));
        m.instructions.insert(begin);sites++;
        int count=0;
        for(AbstractInsnNode a=m.instructions.getFirst();a!=null;a=a.getNext())if(a.getOpcode()==RETURN){
            InsnList x=new InsnList();x.add(new VarInsnNode(ALOAD,3));
            x.add(new MethodInsnNode(INVOKESTATIC,LIB+"Rev309TooltipOrder","finish","(Ljava/util/List;)V",false));
            m.instructions.insertBefore(a,x);count++;
        }
        if(count!=1)throw new IllegalStateException("tooltip return count "+count);sites++;
    }
}
