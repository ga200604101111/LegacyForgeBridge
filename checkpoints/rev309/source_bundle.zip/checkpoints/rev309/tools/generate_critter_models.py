#!/usr/bin/env python3
"""Source-grounded geometric 1.7.10 TESR reconstruction in static JSON cuboids.
Source: Twilight 2.3.8-tw ModelTFCicada and ModelTFFirefly javap; no JVM loading.
"""
import json, math
from pathlib import Path
from itertools import product
OUTPUT=Path('/mnt/data/lfb309work/resources/legacyforgebridge/rev309/templates')
OUTPUT.mkdir(parents=True,exist_ok=True)
# ModelRenderer.addBox source 1.7.10 arguments: box coords, width height depth, atlas U,V. Pivot=0.
critters={
 'cicada':[('legs',-4,7.9,-5,8,1,9,0,21),('fatbody',-2,6,-4,4,2,6,0,11),('skinnybody',-1,7,-5,2,1,8,0,0),('eye1',1,5,2,2,2,2,20,15),('eye2',-3,5,2,2,2,2,20,15),('wings',-4,5,-7,8,1,8,20,0)],
 'firefly':[('legs',-4,7.9,-5,8,1,10,0,21),('fatbody',-2,6,-4,4,2,6,0,11),('skinnybody',-1,7,-5,2,1,8,0,0),('glow',-5,5.9,-9,10,0,10,20,0)]
}
# The old TESR centers at block + (0.5,0.5,0.5); scale(1,-1,-1), then z-rotation, then x rotation.
angles={0:(90,0),1:(90,-90),2:(90,90),3:(90,0),4:(90,180),5:(0,0),6:(180,0)}

def transformed(point,xrot,zrot):
 x,y,z=point; y=-y; z=-z
 rz=math.radians(zrot); xx=x*round(math.cos(rz))-y*round(math.sin(rz)); yy=x*round(math.sin(rz))+y*round(math.cos(rz));zz=z
 rx=math.radians(xrot); zy=yy*round(math.cos(rx))-zz*round(math.sin(rx)); zz2=yy*round(math.sin(rx))+zz*round(math.cos(rx))
 return (8+xx,8+zy,8+zz2)

def face_uv(w,h,d,u,v):
 # 1.7 ModelBox unfolded UV ordering; stored in pixel units in a 64x32 source texture.
 regions={
  'west':(u,v+d,u+d,v+d+h),
  'down':(u+d+w,v,u+d+2*w,v+d),
  'east':(u+d+w,v+d,u+2*d+w,v+d+h),
  'up':(u+d,v,u+d+w,v+d),
  'north':(u+d,v+d,u+d+w,v+d+h),
  'south':(u+d+w+d,v+d,u+2*d+2*w,v+d+h),
 }
 return {side:[round(a*16/64,4),round(b*16/32,4),round(c*16/64,4),round(dd*16/32,4)] for side,(a,b,c,dd) in regions.items()}

def normal_to_side(v):
 return {(1,0,0):'east',(-1,0,0):'west',(0,1,0):'up',(0,-1,0):'down',(0,0,1):'south',(0,0,-1):'north'}[tuple(int(q) for q in v)]

def make(kind,meta):
 xrot,zrot=angles[meta]
 elements=[]
 for name,x,y,z,w,h,d,u,v in critters[kind]:
  # The 1.7 renderer supports a face of zero thickness for the firefly glow;
  # MC baked JSON needs a nonzero thickness to avoid culling it entirely.
  minp=(x,y-0.015 if h==0 else y,z)
  maxp=(x+w,y+0.015 if h==0 else y+h,z+d)
  pts=[transformed(p,xrot,zrot) for p in product((minp[0],maxp[0]),(minp[1],maxp[1]),(minp[2],maxp[2]))]
  bounds=[[round(min(p[axis] for p in pts),4) for axis in range(3)], [round(max(p[axis] for p in pts),4) for axis in range(3)]]
  uv=face_uv(w,h,d,u,v)
  faces={}
  normals={'west':(-1,0,0),'east':(1,0,0),'up':(0,1,0),'down':(0,-1,0),'north':(0,0,-1),'south':(0,0,1)}
  for oldside,normal in normals.items():
   world_normal=transformed(normal,xrot,zrot)
   world_center=transformed((0,0,0),xrot,zrot)
   vector=tuple(world_normal[i]-world_center[i] for i in range(3))
   side=normal_to_side(vector)
   faces[side]={'texture':'#model','uv':uv[oldside]}
  element={'from':bounds[0],'to':bounds[1],'shade':False,'faces':faces}
  elements.append(element)
 output={'credit':'Original Twilight Forest 1.7.10 TESR box geometry and texture UV; LFB rev309','ambientocclusion':False,'textures':{'model':f'twilightforest:model/{"cicada-model" if kind=="cicada" else "firefly-tiny"}','particle':f'twilightforest:blocks/{"TFCicada" if kind=="cicada" else "TFFirefly"}'},'elements':elements}
 return output

for kind in critters:
 for meta in sorted(angles):
  out=make(kind,meta);p=OUTPUT/f'{kind}_{meta}.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
  print(p.name,len(out['elements']),'extents',[[min(q['from'][i] for q in out['elements']),max(q['to'][i] for q in out['elements'])] for i in range(3)])
