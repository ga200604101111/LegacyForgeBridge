package dev.yinghuang.legacyforgebridge.rev309;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.yinghuang.legacyforgebridge.convert.runtime.ConvertedLegacyBlock;
import dev.yinghuang.legacyforgebridge.convert.runtime.ConvertedModCatalog;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_2248;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_2398;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** Model-derived shape, firefly light and client particles for an exact original-TF-source pair.
 * No clientside game mechanics, legacy TileEntity execution or world mutation.
 */
public final class Rev309CritterClient {
    private enum Kind { CICADA, FIREFLY }
    private static volatile Map<String,Kind> SOURCE_BLOCKS;
    private Rev309CritterClient() {}

    private static Map<String,Kind> sourceBlocks() {
        Map<String,Kind> now=SOURCE_BLOCKS;
        if(now!=null)return now;
        synchronized(Rev309CritterClient.class) {
            if(SOURCE_BLOCKS!=null)return SOURCE_BLOCKS;
            Map<String,Kind> found=new HashMap<>();
            try {
                if(ConvertedModCatalog.loadedSourceSha256("twilightforest")
                        .filter(Rev309CritterModelBake.TWILIGHT_SOURCE_SHA256::equals).isPresent()) {
                    var c=FabricLoader.getInstance().getModContainer("twilightforest").orElseThrow();
                    var source=c.findPath("legacyforgebridge/converted-content.json").orElseThrow();
                    JsonArray blocks=JsonParser.parseString(Files.readString(source,StandardCharsets.UTF_8))
                            .getAsJsonObject().getAsJsonArray("blocks");
                    if(blocks!=null)for(JsonElement entry:blocks){
                        if(!entry.isJsonObject())continue;
                        JsonObject block=entry.getAsJsonObject();
                        String origin=block.has("sourceClass")?block.get("sourceClass").getAsString():"";
                        Kind kind=switch(origin){
                            case "twilightforest/block/BlockTFCicada"->Kind.CICADA;
                            case "twilightforest/block/BlockTFFirefly"->Kind.FIREFLY;
                            default->null;};
                        if(kind==null||!block.has("id"))continue;
                        String id=block.get("id").getAsString();
                        if(id.startsWith("twilightforest:"))found.put(id,kind);
                    }
                }
            } catch(Exception|LinkageError ignored) {found.clear();}
            SOURCE_BLOCKS=Map.copyOf(found);
            return SOURCE_BLOCKS;
        }
    }
    private static Kind type(class_2960 id){return id==null?null:sourceBlocks().get(id.toString());}

    public static class_4970.class_2251 properties(class_2960 id, class_4970.class_2251 settings) {
        Kind kind=type(id);
        if(kind==null)return settings;
        settings.method_9634(); // Forge BlockTFCritter has null collision and no opacity.
        if(kind==Kind.FIREFLY)settings.method_9631(state->15); // Source BlockTFFirefly.getLightValue()==15.
        return settings;
    }
    /** Explicitly enable alpha-tested faces. Opaque SOLID leaves transparent atlas pixels dark. */
    public static void renderLayer(class_2960 id, class_2248 block) {
        if(type(id)==null || block==null)return;
        BlockRenderLayerMap.putBlock(block, class_11515.field_60925);
    }
    public static class_265 selection(class_265 original, class_2960 id,class_2680 state) {
        if(type(id)==null)return original;
        int meta=ConvertedLegacyBlock.legacyMeta(state)&7;
        // Same 1.7 source BlockTFCritter.setBlockBoundsBasedOnState 0.15 margin.
        return switch(meta){
            case 1 -> class_259.method_1081(0,0.2,0.35,0.3,0.8,0.65);
            case 2 -> class_259.method_1081(0.7,0.2,0.35,1,0.8,0.65);
            case 3 -> class_259.method_1081(0.35,0.2,0,0.65,0.8,0.3);
            case 4 -> class_259.method_1081(0.35,0.2,0.7,0.65,0.8,1);
            case 5 -> class_259.method_1081(0.35,0,0.35,0.65,0.3,0.65);
            case 6 -> class_259.method_1081(0.35,0.7,0.35,0.65,1,0.65);
            default -> class_259.method_1081(0.35,0.2,0,0.65,0.8,0.3);
        };
    }
    public static class_265 collision(class_265 original,class_2960 id) {
        return type(id)!=null?class_259.method_1073():original;
    }
    public static void tick(class_2960 id,class_2680 state,class_1937 world,class_2338 pos,class_5819 random) {
        Kind kind=type(id);
        if(kind==null||!world.method_8608())return;
        double x=pos.method_10263()+0.5,y=pos.method_10264()+0.5,z=pos.method_10260()+0.5;
        if(kind==Kind.CICADA) {
            if(random.method_43048(14)==0) {
                // Original client TileEntityTFCicada#doSingAnimation emits the "note" particle.
                world.method_8406(class_2398.field_11224,x+(random.method_43057()-0.5)*0.3,
                        y+(random.method_43057()-0.5)*0.3,z+(random.method_43057()-0.5)*0.3,0,0,0);
            }
        } else if(random.method_43048(5)==0) {
            // Source firefly flickers its glow layer; modern ambient firefly particles express this.
            int meta=ConvertedLegacyBlock.legacyMeta(state)&7;
            double offset=0.23;
            switch(meta){
                case 1 -> x-=offset;
                case 2 -> x+=offset;
                case 3 -> z-=offset;
                case 4 -> z+=offset;
                case 5 -> y-=offset;
                case 6 -> y+=offset;
                default -> { }
            }
            world.method_8406(class_2398.field_56509,
                    x+(random.method_43057()-0.5)*0.15,
                    y+(random.method_43057()-0.5)*0.22,
                    z+(random.method_43057()-0.5)*0.15,0,0,0);
        }
    }
}
