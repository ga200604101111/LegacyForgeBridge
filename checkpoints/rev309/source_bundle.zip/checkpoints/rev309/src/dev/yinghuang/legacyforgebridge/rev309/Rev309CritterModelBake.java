package dev.yinghuang.legacyforgebridge.rev309;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Late staged-resource correction for source-proven attachable 1.7.10 TESR insect blocks.
 * Uses original 1.7.10 ModelRenderer cuboid dimensions/UVs and six attachment directions.
 * Does not load or change original Forge classes, or modify server game logic.
 */
public final class Rev309CritterModelBake {
    public static final String TWILIGHT_SOURCE_SHA256 =
            "1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589";
    private static final String RESOURCE = "legacyforgebridge/rev309/templates/";
    private Rev309CritterModelBake() {}

    /** Runs at the last instant before deterministic candidate packaging. */
    public static void apply(Path staging) throws IOException {
        Path metadataFile = staging.resolve("fabric.mod.json");
        Path contentFile = staging.resolve("legacyforgebridge/converted-content.json");
        if (!Files.isRegularFile(metadataFile) || !Files.isRegularFile(contentFile)) return;
        JsonObject metadata = read(metadataFile);
        if (!"twilightforest".equals(text(metadata, "id"))) return;
        JsonElement custom = metadata.get("custom");
        if (custom == null || !custom.isJsonObject()) return;
        JsonElement lfb = custom.getAsJsonObject().get("legacyforgebridge");
        if (lfb == null || !lfb.isJsonObject() ||
                !TWILIGHT_SOURCE_SHA256.equals(text(lfb.getAsJsonObject(), "sourceSha256"))) return;
        JsonArray blocks = read(contentFile).getAsJsonArray("blocks");
        if (blocks == null) return;
        Map<String,String> identified = new HashMap<>();
        for (JsonElement e : blocks) {
            if (!e.isJsonObject()) continue;
            JsonObject block = e.getAsJsonObject();
            String sourceClass = text(block,"sourceClass");
            if (sourceClass == null) continue;
            String kind = switch (sourceClass) {
                case "twilightforest/block/BlockTFCicada" -> "cicada";
                case "twilightforest/block/BlockTFFirefly" -> "firefly";
                default -> null;
            };
            if (kind == null) continue;
            String id = text(block,"id");
            if (id == null || !id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")) return;
            if (identified.putIfAbsent(kind,id) != null) return; // ambiguous, fail closed
        }
        if (identified.size() != 2) return;
        // Stage every input before modifying anything, to avoid half-written models.
        Map<String,String> templates = new HashMap<>();
        for (String kind : identified.keySet()) for (int meta=0;meta<=6;meta++) {
            String key = kind+"_"+meta;
            try (InputStream input=Rev309CritterModelBake.class.getClassLoader()
                    .getResourceAsStream(RESOURCE+key+".json")) {
                if (input == null) throw new IOException("Missing source-proven critter model: "+key);
                String json = new String(input.readAllBytes(),StandardCharsets.UTF_8);
                JsonParser.parseString(json).getAsJsonObject();
                templates.put(key,json);
            }
        }
        for (Map.Entry<String,String> block : identified.entrySet()) {
            String kind=block.getKey(), id=block.getValue();
            int colon=id.indexOf(':');String ns=id.substring(0,colon),name=id.substring(colon+1);
            Path base=staging.resolve("assets").resolve(ns);
            Path modelDir=base.resolve("models/block");
            Files.createDirectories(modelDir);
            for(int meta=0;meta<=6;meta++) {
                Path file=modelDir.resolve(name+"_lfb_critter_"+meta+".json");
                Files.writeString(file, templates.get(kind+"_"+meta),StandardCharsets.UTF_8);
            }
            JsonObject variants=new JsonObject();
            for(int raw=0;raw<16;raw++) {
                int meta=raw&7;if(meta>6)meta=3;
                JsonObject model=new JsonObject();
                model.addProperty("model", ns+":block/"+name+"_lfb_critter_"+meta);
                variants.add("legacy_meta="+raw,model);
            }
            JsonObject output=new JsonObject();output.add("variants",variants);
            Path stateFile=base.resolve("blockstates").resolve(name+".json");
            Files.createDirectories(stateFile.getParent());
            Files.writeString(stateFile,output.toString()+"\n",StandardCharsets.UTF_8);
        }
    }
    private static JsonObject read(Path p) throws IOException {
        try {return JsonParser.parseString(Files.readString(p,StandardCharsets.UTF_8)).getAsJsonObject();}
        catch(RuntimeException e){throw new IOException("Invalid staged LFB metadata: "+p,e);}
    }
    private static String text(JsonObject o,String k){
        JsonElement e=o.get(k);return e!=null && e.isJsonPrimitive()?e.getAsString():null;
    }
}
