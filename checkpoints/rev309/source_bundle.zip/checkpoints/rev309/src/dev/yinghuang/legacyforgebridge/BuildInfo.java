package dev.yinghuang.legacyforgebridge;
/** Rev309 visual/tooltip patch; cache rebuild required for generated model assets. */
public final class BuildInfo {
    public static final String VERSION = text("0.2.0-alpha.27-corpus4-local.62-rev309-critter-model-fx-tooltips.1");
    public static final int CONVERSION_SCHEMA = number(2);
    public static final String CONVERTER_REVISION = text("2026-10-09.309-critter-model-uv-and-attachment-proofs");
    public static final String CACHE_COMPATIBILITY_VERSION =
            text("0.2.0-alpha.27-corpus4-local.17-rev233-cache.1");
    private BuildInfo() {}
    private static String text(String s) {return s;}
    private static int number(int n) {return n;}
}
