package dev.yinghuang.legacyforgebridge.rev309;

import net.minecraft.class_2561;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/** Moves only newly added LFB tooltip lines immediately after the name (slot one).
 * Baseline components were provided before the LFB ItemTooltipCallback started.
 * No global tooltip insertion/order of other mods is changed.
 */
public final class Rev309TooltipOrder {
    private static final ThreadLocal<Deque<List<class_2561>>> BASELINES=ThreadLocal.withInitial(ArrayDeque::new);
    private Rev309TooltipOrder() {}
    public static void begin(List<class_2561> lines){
        BASELINES.get().push(lines==null?List.of():List.copyOf(lines));
    }
    public static void finish(List<class_2561> lines){
        Deque<List<class_2561>> stack=BASELINES.get();
        if(stack.isEmpty())return;
        List<class_2561> baseline=stack.pop();
        if(stack.isEmpty())BASELINES.remove();
        if(lines==null||lines.size()<2||lines.size()>256||baseline.isEmpty())return;
        List<class_2561> anchored=new ArrayList<>(),extra=new ArrayList<>();
        int original=1;
        // Monotonic text/identity alignment with the incoming list. Existing text with
        // appended Forge suffixes counts as existing, not as a new independently added line.
        for(int i=1;i<lines.size();i++) {
            class_2561 candidate=lines.get(i);
            boolean match=false;
            for(int j=original;j<baseline.size();j++) {
                class_2561 before=baseline.get(j);
                if(candidate==before||candidate.method_10851().equals(before.method_10851()) ||
                        (!before.method_10851().isEmpty() && candidate.method_10851().startsWith(before.method_10851()))) {
                    original=j+1;match=true;break;
                }
            }
            (match?anchored:extra).add(candidate);
        }
        if(extra.isEmpty())return;
        List<class_2561> ordered=new ArrayList<>(lines.size());
        ordered.add(lines.get(0));ordered.addAll(extra);ordered.addAll(anchored);
        lines.clear();lines.addAll(ordered);
    }
}
