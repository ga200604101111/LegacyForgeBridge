package dev.yinghuang.legacyforgebridge.rev310;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.yinghuang.legacyforgebridge.convert.api.ConversionContext;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Moves an exact, source-proven TESR model producer into the real conversion pass pipeline.
 *
 * <p>LegacyTextureAtlasPass invokes this before building its sprite index, so the same generic
 * block-/item-atlas migration handles all generated textures. Original Forge classes are never
 * loaded or executed; no client-side gameplay/AI is added.</p>
 */
public final class Rev310CritterPreAtlas {
    private static final String SOURCE_SHA256 =
            "1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589";
    private static final String SOURCE_NAMESPACE = "twilightforest";
    private static final String TEMPLATE_ROOT = "legacyforgebridge/rev309/templates/";

    private record Source(String sourceClass, String iconPath, String modelTexture) { }
    private static final Map<String, Source> PROVEN = Map.of(
            "cicada", new Source("twilightforest/block/BlockTFCicada",
                    "blocks/TFCicada", "model/cicada-model"),
            "firefly", new Source("twilightforest/block/BlockTFFirefly",
                    "blocks/TFFirefly", "model/firefly-tiny"));
    private Rev310CritterPreAtlas() { }

    /** Source fingerprint prevents a different release inheriting unrelated renderer assumptions. */
    public static void apply(ConversionContext context) throws IOException {
        if (!SOURCE_SHA256.equals(context.sourceHash())
                || !SOURCE_NAMESPACE.equals(context.metadata().fabricId())) return;
        process(context.stagingDir());
    }

    /** Pure staged-resource transform, suitable for focused offline conversion regression tests. */
    public static void process(Path staging) throws IOException {
        Path contentFile = staging.resolve("legacyforgebridge/converted-content.json");
        if (!Files.isRegularFile(contentFile)) return;
        JsonObject contents = read(contentFile);
        JsonArray blocks = contents.getAsJsonArray("blocks");
        if (blocks == null) return;
        Map<String, String> ids = new LinkedHashMap<>();
        for (JsonElement el : blocks) {
            if (!el.isJsonObject()) continue;
            JsonObject block = el.getAsJsonObject();
            String clazz = text(block, "sourceClass");
            String id = text(block, "id");
            for (Map.Entry<String, Source> e : PROVEN.entrySet()) {
                if (!e.getValue().sourceClass().equals(clazz)) continue;
                if (id == null || !id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+") || id.contains("..")) {
                    throw new IOException("Invalid source-proven critter identifier: " + id);
                }
                if (ids.putIfAbsent(e.getKey(), id) != null) {
                    throw new IOException("Ambiguous source-proven critter registration: " + e.getKey());
                }
            }
        }
        if (ids.isEmpty()) return;
        if (ids.size() != PROVEN.size()) {
            throw new IOException("Incomplete source-proven critter pair; refusing partial model output");
        }

        // Validate every input before writing any output. The ordinary texture-atlas pass will
        // materialize these source legacy paths into the modern block and item atlases afterward.
        Map<String, String> templates = new HashMap<>();
        for (String kind : ids.keySet()) {
            Source s = PROVEN.get(kind);
            Path sourceIcon = staging.resolve("assets/" + SOURCE_NAMESPACE + "/textures/" + s.iconPath() + ".png");
            Path sourceModel = staging.resolve("assets/" + SOURCE_NAMESPACE + "/textures/" + s.modelTexture() + ".png");
            if (!Files.isRegularFile(sourceIcon) || !Files.isRegularFile(sourceModel))
                throw new IOException("Missing original sprite for " + kind + ": icon=" + sourceIcon + " model=" + sourceModel);
            for (int variant = 0; variant <= 6; variant++) {
                String key = kind + "_" + variant;
                try (InputStream in = Rev310CritterPreAtlas.class.getClassLoader()
                        .getResourceAsStream(TEMPLATE_ROOT + key + ".json")) {
                    if (in == null) throw new IOException("Missing model template: " + key);
                    String json = new String(in.readAllBytes(), StandardCharsets.UTF_8);
                    JsonObject template = JsonParser.parseString(json).getAsJsonObject();
                    JsonObject textures = template.getAsJsonObject("textures");
                    String expected = SOURCE_NAMESPACE + ":" + s.modelTexture();
                    if (textures == null || !expected.equals(text(textures, "model"))
                            || !expected.equals(text(textures, "particle"))) {
                        throw new IOException("Incorrect template source texture: " + key);
                    }
                    templates.put(key, json);
                } catch (RuntimeException malformed) {
                    throw new IOException("Malformed model template " + key, malformed);
                }
            }
        }

        for (Map.Entry<String, String> entry : ids.entrySet()) {
            String kind = entry.getKey(), id = entry.getValue();
            Source source = PROVEN.get(kind);
            int colon = id.indexOf(':');
            String ns = id.substring(0, colon), path = id.substring(colon + 1);
            if (!SOURCE_NAMESPACE.equals(ns)) throw new IOException("Unexpected source namespace: " + ns);
            Path root = staging.resolve("assets/" + ns);
            Path modelDir = root.resolve("models/block");
            Files.createDirectories(modelDir);
            for (int variant = 0; variant <= 6; variant++) {
                Files.writeString(modelDir.resolve(path + "_lfb_critter_" + variant + ".json"),
                        templates.get(kind + "_" + variant), StandardCharsets.UTF_8);
            }
            JsonObject variants = new JsonObject();
            for (int raw = 0; raw < 16; raw++) {
                int attachment = raw & 7;
                if (attachment > 6) attachment = 3;
                JsonObject model = new JsonObject();
                model.addProperty("model", ns + ":block/" + path + "_lfb_critter_" + attachment);
                variants.add("legacy_meta=" + raw, model);
            }
            JsonObject states = new JsonObject();
            states.add("variants", variants);
            Path stateFile = root.resolve("blockstates").resolve(path + ".json");
            Files.createDirectories(stateFile.getParent());
            Files.writeString(stateFile, states + "\n", StandardCharsets.UTF_8);

            // 1.7.10 RenderBlockTFCritters.shouldRender3DInInventory(int) returns literal false.
            // The original block's icon registration provides a separate 16x16 BLOCK sprite.
            // Reusing that sprite in the item model is source-proven; do not use the world TESR.
            Path inventoryModel = root.resolve("models/item").resolve(path + ".json");
            Files.createDirectories(inventoryModel.getParent());
            JsonObject icon = new JsonObject();
            icon.addProperty("parent", "minecraft:item/generated");
            JsonObject textures = new JsonObject();
            textures.addProperty("layer0", ns + ":" + source.iconPath());
            icon.add("textures", textures);
            Files.writeString(inventoryModel, icon + "\n", StandardCharsets.UTF_8);
            JsonObject itemModel = new JsonObject();
            itemModel.addProperty("type", "minecraft:model");
            itemModel.addProperty("model", ns + ":item/" + path);
            JsonObject definition = new JsonObject();
            definition.add("model", itemModel);
            Path itemPath = root.resolve("items").resolve(path + ".json");
            Files.createDirectories(itemPath.getParent());
            Files.writeString(itemPath, definition + "\n", StandardCharsets.UTF_8);
        }
    }

    private static JsonObject read(Path path) throws IOException {
        try {
            return JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (RuntimeException malformed) {
            throw new IOException("Malformed staged converted-content: " + path, malformed);
        }
    }
    private static String text(JsonObject object, String field) {
        JsonElement element = object.get(field);
        return element != null && element.isJsonPrimitive() ? element.getAsString() : null;
    }
}
