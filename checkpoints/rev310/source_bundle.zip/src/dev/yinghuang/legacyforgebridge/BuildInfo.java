package dev.yinghuang.legacyforgebridge;
/** Rev310: pre-atlas TESR bake and source-flat BlockItem icon; rebuild converted resources. */
public final class BuildInfo {
    public static final String VERSION = text("0.2.0-alpha.27-corpus4-local.64-rev310-critter-pre-atlas-flat-item.1");
    public static final int CONVERSION_SCHEMA = number(2);
    public static final String CONVERTER_REVISION = text("2026-10-09.310-pre-atlas-critter-source-flat-icon");
    public static final String CACHE_COMPATIBILITY_VERSION =
            text("0.2.0-alpha.27-corpus4-local.17-rev233-cache.1");
    private BuildInfo() { }
    private static String text(String v) { return v; }
    private static int number(int n) { return n; }
}
