#!/usr/bin/env python3
"""Repackage exact rev309.1 main with pre-atlas model hook, preserving unrelated binary payloads.

Expected build steps (Java 21):
  javac --release 21 -cp <rev309.1-main>:<temporary-Gson-test-signature-stubs> -d classes Rev310*.java BuildInfo.java
  javac --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED \\
        --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED \\
        -d tools tools/TransformRev310.java
  java --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED \\
       --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED \\
       -cp tools TransformRev310 original patches
  python tools/package_rev310.py
The temporary stub classes and ASM are NOT included in the installable JAR.
"""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/mnt/data/legacyforgebridge-0.2.0-alpha.27-rev309.1-critter-identifier-fix.jar')
OUTPUT=Path('/mnt/data/legacyforgebridge-0.2.0-alpha.27-rev310-critter-atlas-inventory.jar')
BASE_SHA='40aace814710d9d5d841c8c58d755f3619567c87c90df35ce1af92cde82c01cf'
VERSION='0.2.0-alpha.27-corpus4-local.64-rev310-critter-pre-atlas-flat-item.1'
REVISION='2026-10-09.310-pre-atlas-critter-source-flat-icon'

def sha(p):
    with p.open('rb') as file: return hashlib.file_digest(file,'sha256').hexdigest()

if sha(BASE)!=BASE_SHA:raise RuntimeError('Wrong rev309.1 base, abort')
updates={p.relative_to(ROOT/'classes').as_posix():p.read_bytes() for p in (ROOT/'classes').rglob('*.class')}
for p in (ROOT/'patches').rglob('*.class'):
    relative=p.relative_to(ROOT/'patches').as_posix()
    if relative in updates:raise RuntimeError('Duplicate class '+relative)
    updates[relative]=p.read_bytes()
with zipfile.ZipFile(BASE) as old:
    existing=old.namelist()
    if len(existing)!=len(set(existing)):raise RuntimeError('Baseline duplicates')
    meta=json.loads(old.read('fabric.mod.json'))
    meta['version']=VERSION
    meta['description']='rev310: fix late TESR model generation by using original generic texture-atlas conversion on world models and source-proven 2D block inventory icons; preserves rev309 particle, tooltip, rev308 weapon/arrow, rev307 config bridge. Original server authority unchanged.'
    updates['fabric.mod.json']=(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode()
    replaced={p for p in updates if p in existing}
    expected={'dev/yinghuang/legacyforgebridge/BuildInfo.class',
              'dev/yinghuang/legacyforgebridge/convert/LegacyJarWriter.class',
              'dev/yinghuang/legacyforgebridge/convert/pass/LegacyTextureAtlasPass.class','fabric.mod.json'}
    if replaced!=expected:raise RuntimeError('Unexpected replacements: '+str(replaced^expected))
    additions=set(updates)-set(existing)
    if additions!={'dev/yinghuang/legacyforgebridge/rev310/Rev310CritterPreAtlas.class',
                   'dev/yinghuang/legacyforgebridge/rev310/Rev310CritterPreAtlas$Source.class'}:
        raise RuntimeError('Unexpected additions '+str(additions))
    with zipfile.ZipFile(OUTPUT,'w') as target:
        for ent in old.infolist():target.writestr(ent,updates.get(ent.filename,old.read(ent.filename)))
        for name in sorted(additions):
            ent=zipfile.ZipInfo(name,(1980,1,1,0,0,0));ent.compress_type=zipfile.ZIP_DEFLATED
            target.writestr(ent,updates[name])
with zipfile.ZipFile(BASE) as old,zipfile.ZipFile(OUTPUT) as made:
    if made.testzip() is not None:raise RuntimeError('CRC fail')
    if len(made.namelist())!=len(set(made.namelist())):raise RuntimeError('Duplicate entries')
    unchanged=[name for name in old.namelist() if name not in replaced]
    for name in unchanged:
        if old.read(name)!=made.read(name):raise RuntimeError('Accidental mutation: '+name)
    if json.loads(made.read('fabric.mod.json'))['version']!=VERSION:raise RuntimeError('Metadata version')
    bi=made.read('dev/yinghuang/legacyforgebridge/BuildInfo.class')
    if VERSION.encode() not in bi or REVISION.encode() not in bi:raise RuntimeError('BuildInfo mismatch')
    for name in made.namelist():
        if name.startswith(('org/objectweb/asm/','jdk/internal/org/objectweb/asm/','com/google/gson/')):
            raise RuntimeError('Forbidden embedded test/runtime type '+name)
    print('BASE_SHA256',sha(BASE));print('REV310_SHA256',sha(OUTPUT))
    print('REV310_BYTES',OUTPUT.stat().st_size)
    print('PAYLOAD_PRESERVED',len(unchanged))
    print('REPLACED',len(replaced),'ADDED',len(additions))
    print('ZIP_VALID',True,'NO_DUPLICATES',True,'NO_TEST_STUBS',True)
    print('VERSION',VERSION,'CONVERTER_REVISION',REVISION)
    print('OUTPUT',OUTPUT)
