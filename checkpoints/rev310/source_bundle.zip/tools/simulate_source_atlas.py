#!/usr/bin/env python3
"""Independent byte-exact source-sprite atlas fixture (not a Minecraft runtime test)."""
import hashlib,zipfile,json,io,tempfile
from pathlib import Path
from PIL import Image
SRC=Path('/mnt/data/twilightforest-1.7.10-2.3.8-tw.jar')
LFB=Path('/mnt/data/legacyforgebridge-0.2.0-alpha.27-rev310-critter-atlas-inventory.jar')
CASES={
 'cicada':{'block':'tfcicada','world':'model/cicada-model','icon':'blocks/TFCicada'},
 'firefly':{'block':'tffirefly','world':'model/firefly-tiny','icon':'blocks/TFFirefly'},
}
assert hashlib.file_digest(SRC.open('rb'),'sha256').hexdigest()=='1aa2c191170ff707499c42cd58bdcc69f2772b59014cb684ba99a6d1e6540589'
with zipfile.ZipFile(SRC) as source,zipfile.ZipFile(LFB) as bridge:
 with tempfile.TemporaryDirectory(prefix='lfb-rev310-atlas-fixture-') as td:
  stage=Path(td)
  for case in CASES.values():
   for asset in (case['world'],case['icon']):
    name='assets/twilightforest/textures/'+asset+'.png'
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read(name))
  blocks=set();items=set()
  for kind,case in CASES.items():
   name=case['block'];base=stage/'assets/twilightforest';models=base/'models/block';models.mkdir(parents=True,exist_ok=True)
   for i in range(7):
    template='legacyforgebridge/rev309/templates/'+kind+'_'+str(i)+'.json'
    model=json.loads(bridge.read(template))
    assert model['textures']['model']=='twilightforest:'+case['world'],template
    assert model['textures']['particle']=='twilightforest:'+case['world'],template
    old='twilightforest/textures/'+case['world']+'.png';digest=hashlib.sha256(old.encode()).hexdigest()
    modern='twilightforest:block/lfb_legacy/'+digest
    target=base/'textures/block/lfb_legacy'/f'{digest}.png';target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(source.read('assets/'+old))
    model['textures']['model']=modern;model['textures']['particle']=modern;blocks.add(modern)
    (models/f'{name}_lfb_critter_{i}.json').write_text(json.dumps(model))
   icon=case['icon'];old='twilightforest/textures/'+icon+'.png';digest=hashlib.sha256(old.encode()).hexdigest()
   modern='twilightforest:item/lfb_legacy/'+digest
   tgt=base/'textures/item/lfb_legacy'/f'{digest}.png';tgt.parent.mkdir(parents=True,exist_ok=True);tgt.write_bytes(source.read('assets/'+old));items.add(modern)
   generated={'parent':'minecraft:item/generated','textures':{'layer0':modern}}
   x=base/'models/item'/f'{name}.json';x.parent.mkdir(parents=True,exist_ok=True);x.write_text(json.dumps(generated))
   variants={f'legacy_meta={j}':{'model':f'twilightforest:block/{name}_lfb_critter_{(j&7) if (j&7)<=6 else 3}'} for j in range(16)}
   x=base/'blockstates'/f'{name}.json';x.parent.mkdir(parents=True,exist_ok=True);x.write_text(json.dumps({'variants':variants}))
  for atlas,sprites in [('blocks',blocks),('items',items)]:
   x=stage/'assets/minecraft/atlases'/f'{atlas}.json';x.parent.mkdir(parents=True,exist_ok=True)
   x.write_text(json.dumps({'sources':[{'type':'minecraft:single','resource':s} for s in sorted(sprites)]}))
  # Assert no block item requires a block sprite, and all referenced atlas sprites exist.
  for atlas in ['blocks','items']:
   j=json.loads((stage/'assets/minecraft/atlases'/f'{atlas}.json').read_text())
   for entry in j['sources']:
    sprite=entry['resource']; ns,path=sprite.split(':',1)
    png=stage/'assets'/ns/'textures'/f'{path}.png'
    assert png.is_file(),(atlas,sprite)
    im=Image.open(png)
    assert im.size in [(16,16),(64,32)]
  for kind,case in CASES.items():
   name=case['block'];prefix=stage/'assets/twilightforest';item=json.loads((prefix/'models/item'/f'{name}.json').read_text())
   assert item['parent']=='minecraft:item/generated'
   assert item['textures']['layer0'] in items
   for variant in range(7):
    model=json.loads((prefix/'models/block'/f'{name}_lfb_critter_{variant}.json').read_text())
    assert all(v in blocks for v in model['textures'].values())
    assert model['elements']
   state=json.loads((prefix/'blockstates'/f'{name}.json').read_text())
   assert len(state['variants'])==16
  print('PASS rev310 source-sprite/atlas fixture:')
  print('  original source model textures:',len(blocks),'-> generated world models:',len(CASES)*7)
  print('  original source item sprites:',len(items),'-> flat inventory models:',len(CASES))
  print('  atlases independent: blocks and items (1.21.11)')
  print('  blockstates:',len(CASES)*16,'variants; 0 unresolved sprite references')
  print('  files copied byte-identically from original 1.7.10 JAR')
  print('  game/VFP runtime was not executed')
