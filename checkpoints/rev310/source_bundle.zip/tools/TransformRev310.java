import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import java.nio.file.*;

/** Pure structural bytecode surgery: remove post-atlas bake and install pre-atlas stage. */
public final class TransformRev310 implements Opcodes {
    private static final String BAKE_OLD = "dev/yinghuang/legacyforgebridge/rev309/Rev309CritterModelBake";
    private static final String BAKE_NEW = "dev/yinghuang/legacyforgebridge/rev310/Rev310CritterPreAtlas";
    private static final String CONTEXT = "Ldev/yinghuang/legacyforgebridge/convert/api/ConversionContext;";
    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("Usage: TransformRev310 baseline-extract modified-out");
        Path input=Path.of(args[0]),output=Path.of(args[1]);
        patch(input,output,"dev/yinghuang/legacyforgebridge/convert/LegacyJarWriter",false);
        patch(input,output,"dev/yinghuang/legacyforgebridge/convert/pass/LegacyTextureAtlasPass",true);
    }
    private static void patch(Path root,Path dest,String owner,boolean beforeAtlas) throws Exception {
        ClassNode n=new ClassNode();new ClassReader(Files.readAllBytes(root.resolve(owner+".class"))).accept(n,0);
        MethodNode target=null;
        for (MethodNode method:n.methods) if (method.name.equals(beforeAtlas?"apply":"writeDeterministic")
                && method.desc.equals(beforeAtlas?"("+CONTEXT+")V":"(Ljava/nio/file/Path;Ljava/nio/file/Path;)V")) target=method;
        if(target==null)throw new IllegalStateException("Unexpected class method signature "+owner);
        if(beforeAtlas){
            InsnList code=new InsnList();
            code.add(new VarInsnNode(ALOAD,1));
            code.add(new MethodInsnNode(INVOKESTATIC,BAKE_NEW,"apply","("+CONTEXT+")V",false));
            target.instructions.insert(code);
        }else{
            int removed=0;
            for(AbstractInsnNode p=target.instructions.getFirst();p!=null;){
                AbstractInsnNode next=p.getNext();
                if(p instanceof MethodInsnNode m&&m.getOpcode()==INVOKESTATIC&&m.owner.equals(BAKE_OLD)
                        &&m.name.equals("apply")&&m.desc.equals("(Ljava/nio/file/Path;)V")) {
                    AbstractInsnNode prev=p.getPrevious();
                    if(!(prev instanceof VarInsnNode load)||prev.getOpcode()!=ALOAD||load.var!=0)
                        throw new IllegalStateException("Old post-atlas bake call shape changed");
                    target.instructions.remove(prev);target.instructions.remove(p);removed++;
                }
                p=next;
            }
            if(removed!=1)throw new IllegalStateException("Expected one old post-atlas bake, found "+removed);
        }
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);n.accept(w);
        Path out=dest.resolve(owner+".class");Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());
        System.out.println("PASS "+owner+" "+(beforeAtlas?"pre-atlas hook installed":"post-atlas hook removed"));
    }
}
